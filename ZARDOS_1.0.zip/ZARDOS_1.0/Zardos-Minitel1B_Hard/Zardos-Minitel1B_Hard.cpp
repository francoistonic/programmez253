////////////////////////////////////////////////////////////////////////
/*
   Zardos-Minitel1B_Hard - Fichier source - Lomig PERROTIN - 2021
   basé sur la bibliothèque :

   Minitel1B_Hard - Fichier source - Version du 15 juin 2017 à 22h11
   Copyright 2016, 2017 - Eric Sérandour
   http://3615.entropie.org

   Documentation utilisée :
   Spécifications Techniques d'Utilisation du Minitel 1B
   http://543210.free.fr/TV/stum1b.pdf

////////////////////////////////////////////////////////////////////////

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program. If not, see <http://www.gnu.org/licenses/>.
*/
////////////////////////////////////////////////////////////////////////

#include "Zardos-Minitel1B_Hard.h"

////////////////////////////////////////////////////////////////////////
/*
   Public
*/
////////////////////////////////////////////////////////////////////////

Minitel::Minitel(HardwareSerial& serial) : mySerial(serial) {
  // A la mise sous tension du Minitel, la vitesse des échanges entre
  // le Minitel et le périphérique est de 1200 bauds par défaut.
  mySerial.begin(1200);
}
/*--------------------------------------------------------------------*/

void Minitel::writeByte(byte b) {
  // Le bit de parité est mis à 0 si la somme des autres bits est paire
  // et à 1 si elle est impaire.
  boolean parite = 0;
  for (int i=0; i<7; i++) {
    if (bitRead(b,i) == 1)  {
	  parite = !parite;
	}
  }
  if (parite) {
    bitWrite(b,7,1);  // Ecriture du bit de parité
  }
  else {
    bitWrite(b,7,0);  // Ecriture du bit de parité
  }
  mySerial.write(b);  // Envoi de l'octet sur le port série
}
/*--------------------------------------------------------------------*/

byte Minitel::readByte() {
  byte b = mySerial.read();
  // Le bit de parité est à 0 si la somme des autres bits est paire
  // et à 1 si elle est impaire.	
  boolean parite = 0;
  for (int i=0; i<7; i++) {
    if (bitRead(b,i) == 1)  {
	  parite = !parite;
	}
  }
  if (bitRead(b,7) == parite) {  // La transmission est bonne, on peut récupérer la donnée.
	if (bitRead(b,7) == 1) {  // Cas où le bit de parité vaut 1.
      b = b ^ 0b10000000;  // OU exclusif pour mettre le bit de parité à 0 afin de récupérer la donnée.
    }
    return b;
  }
  else {
    return 0xFF;  // Pour indiquer une erreur de parité.
  }
}
/*--------------------------------------------------------------------*/

int Minitel::changeSpeed(int bauds) {  // Voir p.141
  // Format de la commande
  writeBytesPRO(2);  // 0x1B 0x3A
  writeByte(PROG);   // 0x6B
  switch (bauds) {
    case  300 : writeByte(0b1010010); mySerial.begin( 300); break;  // 0x52
    case 1200 : writeByte(0b1100100); mySerial.begin(1200); break;  // 0x64
    case 4800 : writeByte(0b1110110); mySerial.begin(4800); break;  // 0x76
    case 9600 : writeByte(0b1111111); mySerial.begin(9600); break;  // 0x7F (pour le Minitel 2 seulement)
  }
  // Acquittement
  return workingSpeed();  // En bauds (voir section Private ci-dessous)
}
/*--------------------------------------------------------------------*/

int Minitel::currentSpeed() {  // Voir p.141
  // Demande
  writeBytesPRO(1);
  writeByte(STATUS_VITESSE);
  // Réponse
  return workingSpeed();  // En bauds (voir section Private ci-dessous)
}
/*--------------------------------------------------------------------*/

int Minitel::searchSpeed() {
  const int SPEED[4] = { 1200, 4800, 300, 9600 };  // 9600 bauds pour le Minitel 2 seulement
  int i = 0;
  int speed;
  do {
    mySerial.begin(SPEED[i]);
    if (i++ > 3) { i = 0; }
    speed = currentSpeed();
  } while (speed < 0);
  return speed;  // En bauds
}
/*--------------------------------------------------------------------*/

void Minitel::newScreen() {
  writeByte(FF);
  currentSize = GRANDEUR_NORMALE;
}
/*--------------------------------------------------------------------*/

void Minitel::newXY(int x, int y) {
  if (x==1 && y==1) {
    writeByte(RS);
  }
  else {
    // Le code US est suivi de deux caractères non visualisés. Si les
    // octets correspondants à ces deux caractères appartiennent tous deux
    // aux colonnes 4 à 7, ils représentent respectivement (sous forme
    // binaire avec 6 bits utiles) le numéro de rangée et le numéro de
    // colonne du premier caractère du sous-article (voir p.96).
    writeByte(US);
    writeByte(0x40 + y);  // Numéro de rangée
    writeByte(0x40 + x);  // Numéro de colonne
  }
  currentSize = GRANDEUR_NORMALE;
}
/*--------------------------------------------------------------------*/

void Minitel::cursor() {
  writeByte(CON);
}
/*--------------------------------------------------------------------*/

void Minitel::noCursor() {
  writeByte(COFF);
}
/*--------------------------------------------------------------------*/

void Minitel::moveCursorXY(int x, int y) {  // Voir p.95
  attributs(CSI);   // 0x1B 0x5B
  writeBytesP(y);   // Pr : Voir section Private ci-dessous
  writeByte(0x3B);
  writeBytesP(x);   // Pc : Voir section Private ci-dessous
  writeByte(0x48);
}
/*--------------------------------------------------------------------*/

void Minitel::moveCursorLeft(int n) {  // Voir p.94 et 95
  if (n==1) { writeByte(BS); }
  else if (n>1) {
	// Curseur vers la gauche de n colonnes. Arrêt au bord gauche de l'écran.
    attributs(CSI);   // 0x1B 0x5B
    writeBytesP(n);   // Pn : Voir section Private ci-dessous
    writeByte(0x44);
  }
}
/*--------------------------------------------------------------------*/

void Minitel::moveCursorRight(int n) {  // Voir p.94
  if (n==1) { writeByte(HT); }
  else if (n>1) {
	// Curseur vers la droite de n colonnes. Arrêt au bord droit de l'écran.
    attributs(CSI);   // 0x1B 0x5B
    writeBytesP(n);   // Pn : Voir section Private ci-dessous
    writeByte(0x43);
  }
}
/*--------------------------------------------------------------------*/

void Minitel::moveCursorDown(int n) {  // Voir p.94
  if (n==1) { writeByte(LF); }
  else if (n>1) {
	// Curseur vers le bas de n rangées. Arrêt en bas de l'écran.
    attributs(CSI);   // 0x1B 0x5B
    writeBytesP(n);   // Pn : Voir section Private ci-dessous
    writeByte(0x42);
  }
}
/*--------------------------------------------------------------------*/

void Minitel::moveCursorUp(int n) {  // Voir p.94
  if (n==1) { writeByte(VT); }
  else if (n>1) {
	// Curseur vers le haut de n rangées. Arrêt en haut de l'écran.
    attributs(CSI);   // 0x1B 0x5B
    writeBytesP(n);   // Pn : Voir section Private ci-dessous
    writeByte(0x41);
  }	
}
/*--------------------------------------------------------------------*/

void Minitel::moveCursorReturn(int n) {  // Voir p.94
  writeByte(CR);
  moveCursorDown(n);  // Pour davantage de souplesse
}
/*--------------------------------------------------------------------*/

int Minitel::getCursorX() {
  return (getCursorXY() & 0x0000FF) - 0x40;
}
/*--------------------------------------------------------------------*/

int Minitel::getCursorY() {
  return ((getCursorXY() & 0x00FF00) >> 8) - 0x40;
}
/*--------------------------------------------------------------------*/

void Minitel::cancel() {  // Voir p.95
  writeByte(CAN);
}
/*--------------------------------------------------------------------*/

void Minitel::clearScreenFromCursor() {  // Voir p.95
  attributs(CSI);  // 0x1B 0x5B
  // writeByte(0x30);  Inutile
  writeByte(0x4A);
}
/*--------------------------------------------------------------------*/

void Minitel::clearScreenToCursor() {  // Voir p.95
  attributs(CSI);  // 0x1B 0x5B
  writeByte(0x31);
  writeByte(0x4A);
}
/*--------------------------------------------------------------------*/

void Minitel::clearScreen() {  // Voir p.95
  attributs(CSI);  // 0x1B 0x5B
  writeByte(0x32);
  writeByte(0x4A);
}
/*--------------------------------------------------------------------*/

void Minitel::clearLineFromCursor() {  // Voir p.95
  attributs(CSI);  // 0x1B 0x5B
  // writeByte(0x30);  Inutile
  writeByte(0x4B);
}
/*--------------------------------------------------------------------*/

void Minitel::clearLineToCursor() {  // Voir p.95
  attributs(CSI);  // 0x1B 0x5B
  writeByte(0x31);
  writeByte(0x4B);
}
/*--------------------------------------------------------------------*/

void Minitel::clearLine() {  // Voir p.95
  attributs(CSI);  // 0x1B 0x5B
  writeByte(0x32);
  writeByte(0x4B);
}
/*--------------------------------------------------------------------*/

void Minitel::deleteChars(int n) {  // Voir p.95
  attributs(CSI);  // 0x1B 0x5B
  writeBytesP(n);  // Voir section Private ci-dessous
  writeByte(0x50);
}
/*--------------------------------------------------------------------*/

void Minitel::insertChars(int n) {  // Voir p.95
  attributs(CSI);  // 0x1B 0x5B
  writeBytesP(n);  // Voir section Private ci-dessous
  writeByte(0x40);
}
/*--------------------------------------------------------------------*/

void Minitel::startInsert() {  // Voir p.95
  attributs(CSI);  // 0x1B 0x5B
  writeByte(0x34);
  writeByte(0x68);
}
/*--------------------------------------------------------------------*/

void Minitel::stopInsert() {  // Voir p.95
  attributs(CSI);  // 0x1B 0x5B
  writeByte(0x34);
  writeByte(0x6C);
}
/*--------------------------------------------------------------------*/

void Minitel::deleteLines(int n) {  // Voir p.95
  attributs(CSI);  // 0x1B 0x5B
  writeBytesP(n);  // Voir section Private ci-dessous
  writeByte(0x4D);
}
/*--------------------------------------------------------------------*/

void Minitel::insertLines(int n) {  // Voir p.95
  attributs(CSI);  // 0x1B 0x5B
  writeBytesP(n);  // Voir section Private ci-dessous
  writeByte(0x4C);
}
/*--------------------------------------------------------------------*/

void Minitel::textMode() {
  writeByte(SI);  // Accès au jeu G0 (voir p.100)
}
/*--------------------------------------------------------------------*/

void Minitel::graphicMode() {
  writeByte(SO);  // Accès au jeu G1 (voir p.101 & 102)
}
/*--------------------------------------------------------------------*/

int Minitel::pageMode() {
  // Commande
  writeBytesPRO(2);   // 0x1B 0x3A
  writeByte(STOP);    // 0x6A
  writeByte(ROULEAU); // 0x43
  // Acquittement
  return workingMode();
}
/*--------------------------------------------------------------------*/

int Minitel::scrollMode() {
  // Commande
  writeBytesPRO(2);   // 0x1B 0x3A
  writeByte(START);   // 0x69
  writeByte(ROULEAU); // 0x43
  // Acquittement
  return workingMode();
}
/*--------------------------------------------------------------------*/

void Minitel::attributs(byte attribut) {
  writeByte(ESC);  // Accès à la grille C1 (voir p.92)
  writeByte(attribut);
  if (attribut == DOUBLE_HAUTEUR || attribut == DOUBLE_GRANDEUR) {
    moveCursorDown(1);
    currentSize = attribut;
  }
  else if (attribut == GRANDEUR_NORMALE || attribut == DOUBLE_LARGEUR) {
    currentSize = attribut;
  }
}
/*--------------------------------------------------------------------*/

void Minitel::print(String chaine) {
  for (int i=0; i<chaine.length(); i++) {
    unsigned char caractere = chaine.charAt(i);
    if (!isDiacritic(caractere)) {
	  printChar(caractere);
	}
	else {
	  i+=1;  // Un caractère accentué prend la place de 2 caractères
	  caractere = chaine.charAt(i);
	  printDiacriticChar(caractere);
	}
  }
}
/*--------------------------------------------------------------------*/

void Minitel::println(String chaine) {
  print(chaine);
  if (currentSize == DOUBLE_HAUTEUR || currentSize == DOUBLE_GRANDEUR) {
    moveCursorReturn(2);
  }
  else {
    moveCursorReturn(1);
  }
}
/*--------------------------------------------------------------------*/

void Minitel::println() {
  if (currentSize == DOUBLE_HAUTEUR || currentSize == DOUBLE_GRANDEUR) {
    moveCursorReturn(2);
  }
  else {
    moveCursorReturn(1);
  }
}
/*--------------------------------------------------------------------*/

void Minitel::printChar(char caractere) {
  byte charByte = getCharByte(caractere);
  if (isValidChar(charByte)) {
    writeByte(charByte);
  }
}
/*--------------------------------------------------------------------*/

void Minitel::printDiacriticChar(unsigned char caractere) {
  writeByte(SS2);  // // Accès au jeu G2 (voir p.103)
  String diacritics = "àâäèéêëîïôöùûüçÀÂÄÈÉÊËÎÏÔÖÙÛÜÇ";
  // Dans une chaine de caractères, un caractère diacritique prend la
  // place de 2 caractères simples, ce qui explique le /2.
  int index = (diacritics.indexOf(caractere)-1)/2;
  char car;
  switch (index) {
    case( 0): car = 'a'; writeByte(ACCENT_GRAVE); break;
    case( 1): car = 'a'; writeByte(ACCENT_CIRCONFLEXE); break;
    case( 2): car = 'a'; writeByte(TREMA); break;
    case( 3): car = 'e'; writeByte(ACCENT_GRAVE); break;
    case( 4): car = 'e'; writeByte(ACCENT_AIGU); break;
    case( 5): car = 'e'; writeByte(ACCENT_CIRCONFLEXE); break;
    case( 6): car = 'e'; writeByte(TREMA); break;
    case( 7): car = 'i'; writeByte(ACCENT_CIRCONFLEXE); break;
    case( 8): car = 'i'; writeByte(TREMA); break;
    case( 9): car = 'o'; writeByte(ACCENT_CIRCONFLEXE); break;
    case(10): car = 'o'; writeByte(TREMA); break;
    case(11): car = 'u'; writeByte(ACCENT_GRAVE); break;
    case(12): car = 'u'; writeByte(ACCENT_CIRCONFLEXE); break;      
    case(13): car = 'u'; writeByte(TREMA); break;
    case(14): car = 'c'; writeByte(CEDILLE); break;
	case (15):
		car = 'A';
		break;
	case (16):
		car = 'A';
		break;
	case (17):
		car = 'A';
		break;
	case (18):
		car = 'E';
		break;
	case (19):
		car = 'E';
		break;
	case (20):
		car = 'E';
		break;
	case (21):
		car = 'E';
		break;
	case (22):
		car = 'I';
		break;
	case (23):
		car = 'I';
		break;
	case (24):
		car = 'O';
		break;
	case (25):
		car = 'O';
		break;
	case (26):
		car = 'U';
		break;
	case (27):
		car = 'U';
		break;
	case (28):
		car = 'U';
		break;
	case (29):
		car = 'C';
		break;
	}
	printChar(car);
}
/*--------------------------------------------------------------------*/

void Minitel::printSpecialChar(byte b) {
  // N'est pas fonctionnelle pour les diacritiques (accents, tréma et cédille)
  writeByte(SS2);  // Accès au jeu G2 (voir p.103)
  writeByte(b);
}
/*--------------------------------------------------------------------*/

byte Minitel::getCharByte(char caractere) {
  // Voir les codes et séquences émis en mode Vidéotex (Jeu G0 p.100).
  // Dans la chaine ci-dessous, on utilise l'échappement (\) :
  // \" rend au guillemet sa signification littérale.
  // \\ donne à l'antislash sa signification littérale .
  String caracteres = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_xabcdefghijklmnopqrstuvwxyz";
  return (byte) caracteres.lastIndexOf(caractere);
}
/*--------------------------------------------------------------------*/

void Minitel::graphic(byte b, int x, int y) {
  moveCursorXY(x,y);
  graphic(b);
}
/*--------------------------------------------------------------------*/

void Minitel::graphic(byte b) {
  // Voir Jeu G1 page 101.
  if (b <= 0b111111) {
    b = 0x20
      + bitRead(b,5) 
      + bitRead(b,4) * 2
      + bitRead(b,3) * 4
      + bitRead(b,2) * 8
      + bitRead(b,1) * 16
      + bitRead(b,0) * 64;
    if (b == 0x7F) {  // 0b1111111
      b= 0x5F;
    }    
  writeByte(b);
  }
}
/*--------------------------------------------------------------------*/

void Minitel::repeat(int n) {  // Voir p.98
  writeByte(REP);
  writeByte(0x40 + n);
}
/*--------------------------------------------------------------------*/

void Minitel::bip() {  // Voir p.98
  writeByte(BEL);
}
/*--------------------------------------------------------------------*/
void Minitel::echoOFF() {  //coupure echo local 10/05/2021
  writeByte(0x1B); //
  writeByte(0x3B); // ESC + PRO3
  writeByte(0x60); // OFF
  writeByte(0x5A); // reception modem
  writeByte(0x51); // emission ecran
}
/*--------------------------------------------------------------------*/
void Minitel::echoON() {  //coupure echo local 10/05/2021
  writeByte(0x1B); //
  writeByte(0x3B); // ESC + PRO3
  writeByte(0x61); // ON
  writeByte(0x5A); // reception modem
  writeByte(0x51); // emission ecran
}
/*--------------------------------------------------------------------*/
void Minitel::modeMixte(){ // passage en mode mixte
  writeByte(0x1B); // ESC
  writeByte(0x3A); // 
  writeByte(0x32); // 32 = mode mixte // 31 = mode teleinformatique
  writeByte(0x7D); // MIXTE1
}
/*--------------------------------------------------------------------*/
void Minitel::modeVideotex(){ // passage en mode mixte
  writeByte(0x1B); // ESC
  writeByte(0x3A); // 
  writeByte(0x32); // 32 = mode mixte // 31 = mode teleinformatique
  writeByte(0x7E); // VIDEOTEX
}
/*--------------------------------------------------------------------*/
void Minitel::modeTeleInfo(){ // passage en mode Télé Informatique
  writeByte(0x1B); // ESC
  writeByte(0x3A); // 
  writeByte(0x31); // 32 = mode mixte // 31 = mode teleinformatique
  writeByte(0x7D); // teleinfo
}
/*--------------------------------------------------------------------*/

void Minitel::rect(int x1, int y1, int x2, int y2) {
  hLine(x1,y1,x2,BOTTOM);
  vLine(x2,y1+1,y2,RIGHT,DOWN);
  hLine(x1,y2,x2,TOP);
  vLine(x1,y1,y2-1,LEFT,UP);
}
/*--------------------------------------------------------------------*/

void Minitel::hLine(int x1, int y, int x2, int position) {
  textMode();
  moveCursorXY(x1,y);
  switch (position) {
    case TOP    : writeByte(0x7E); break;
    case CENTER : writeByte(0x60); break;
    case BOTTOM : writeByte(0x5F); break;
  }
  repeat(x2-x1);
}
/*--------------------------------------------------------------------*/

void Minitel::vLine(int x, int y1, int y2, int position, int sens) {
  textMode();
  switch (sens) {
	case DOWN : moveCursorXY(x,y1); break;
    case UP   : moveCursorXY(x,y2); break;
  }
  for (int i=0; i<y2-y1; i++) {
    switch (position) {
      case LEFT   : writeByte(0x7B); break;
      case CENTER : writeByte(0x7C); break;
      case RIGHT  : writeByte(0x7D); break;
    }
    switch (sens) {
	  case DOWN : moveCursorLeft(1); moveCursorDown(1); break;
      case UP   : moveCursorLeft(1); moveCursorUp(1); break;
    }
  }
}
/*--------------------------------------------------------------------*/

unsigned long Minitel::getKeyCode() {
  unsigned long code = 0;
  // Code unique
  if (mySerial.available()>0) {
    code = readByte();
  }  
  // Séquences de deux ou trois codes (voir p.118)
  if (code == 0x19) {  // SS2
    while (!mySerial.available()>0);  // Indispensable
    code = (code << 8) + readByte();
    // Les diacritiques (3 codes)
    if ((code == 0x1941) || (code == 0x1942) || (code == 0x1943) || (code == 0x1948) || (code == 0x194B)) {  // Accents, tréma, cédille
	  while (!mySerial.available()>0);  // Indispensable
	  byte caractere = readByte();
	  code = (code << 8) + caractere;
	  switch (code) {  // On convertit le code reçu en un code que l'on peut visualiser sous forme d'un caractère dans le moniteur série du logiciel Arduino avec la fonction write().
	    case 0x194161 : code = 0xE0; break;  // à 
	    case 0x194165 : code = 0xE8; break;  // è
	    case 0x194175 : code = 0xF9; break;  // ù
	    case 0x194265 : code = 0xE9; break;  // é
	    case 0x194361 : code = 0xE2; break;  // â
	    case 0x194365 : code = 0xEA; break;  // ê
	    case 0x194369 : code = 0xEE; break;  // î
	    case 0x19436F : code = 0xF4; break;  // ô
	    case 0x194375 : code = 0xFB; break;  // û
	    case 0x194861 : code = 0xE4; break;  // ä
	    case 0x194865 : code = 0xEB; break;  // ë
	    case 0x194869 : code = 0xEF; break;  // ï
	    case 0x19486F : code = 0xF6; break;  // ö
	    case 0x194875 : code = 0xFC; break;  // ü
	    case 0x194B63 : code = 0xE7; break;  // ç
	    default : code = caractere; break;
	  }
	}
	// Les autres caractères spéciaux disponibles sous Arduino (2 codes)
	else {
	  switch (code) {  // On convertit le code reçu en un code que l'on peut visualiser sous forme d'un caractère dans le moniteur série du logiciel Arduino avec la fonction write().
	    case 0x1923 : code = 0xA3; break;  // Livre
	    case 0x1927 : code = 0xA7; break;  // Paragraphe
	    case 0x1930 : code = 0xB0; break;  // Degré
	    case 0x1931 : code = 0xB1; break;  // Plus ou moins
	    case 0x1938 : code = 0xF7; break;  // Division
	    case 0x197B : code = 0xDF; break;  // Bêta
	  }
	}
  }
  // Touches de fonction (voir p.123)
  else if (code == 0x13) {
    while (!mySerial.available()>0);  // Indispensable
    code = (code << 8) + readByte();
  }  
  // Touches de gestion du curseur lorsque le clavier est en mode étendu (voir p.124)
  // Pour passer au clavier étendu manuellement : Fnct C + E
  // Pour revenir au clavier vidéotex standard  : Fnct C + V
  else if (code == 0x1B) {
	delay(1);  // Indispensable. 0x1B seul correspond à la touche Esc,
	           // on ne peut donc pas utiliser la boucle while (!available()>0).
    if (mySerial.available()>0) {
      code = (code << 8) + readByte();
      while (!mySerial.available()>0);  // Indispensable
      code = (code << 8) + readByte();
    }	  
  }
// Pour test
/*
  if (code != 0) {
    Serial.print(code,HEX);
    Serial.print(" ");
    Serial.write(code);
    Serial.println("");
  }
*/ 
  return code;
}
/*--------------------------------------------------------------------*/

int Minitel::smallMode() {
  // Commande
  writeBytesPRO(2);       // 0x1B 0x3A
  writeByte(START);       // 0x69
  writeByte(MINUSCULES);  // 0x45
  // Acquittement
  return workingMode();
}
/*--------------------------------------------------------------------*/

int Minitel::capitalMode() {
  // Commande
  writeBytesPRO(2);       // 0x1B 0x3A
  writeByte(STOP);        // 0x6A
  writeByte(MINUSCULES);  // 0x45
  // Acquittement
  return workingMode();
}
/*--------------------------------------------------------------------*/

int Minitel::extendedKeyboard() {
  // Commande
  writeBytesPRO(3);                   // 0x1B 0x3B
  writeByte(START);                   // 0x69
  writeByte(CODE_RECEPTION_CLAVIER);  // 0x59
  writeByte(ETEN);                    // 0x41
  // Acquittement
  return workingKeyboard();	
}
/*--------------------------------------------------------------------*/

int Minitel::standardKeyboard() {
  // Commande
  writeBytesPRO(3);                   // 0x1B 0x3B
  writeByte(STOP);                    // 0x6A
  writeByte(CODE_RECEPTION_CLAVIER);  // 0x59
  writeByte(ETEN);                    // 0x41
  // Acquittement
  return workingKeyboard();	
}
/*--------------------------------------------------------------------*/

void Minitel::gohi(int pin)
{
  pinMode(pin, INPUT);
  digitalWrite(pin, HIGH);
}
/*--------------------------------------------------------------------*/

void Minitel::golo(int pin)
{
  pinMode(pin, OUTPUT);
  digitalWrite(pin, LOW);
}
/*--------------------------------------------------------------------*/

void Minitel::mouse_write(char data)
{
  char i;
  char parity = 1;
  /* put pins in output mode */
  gohi(MDATA);
  gohi(MCLK);
  delayMicroseconds(300);
  golo(MCLK);
  delayMicroseconds(300);
  golo(MDATA);
  delayMicroseconds(10);
  /* start bit */
  gohi(MCLK);
  /* wait for mouse to take control of clock); */
  while (digitalRead(MCLK) == HIGH)
    ;
  /* clock is low, and we are clear to send data */
  for (i=0; i < 8; i++) {
    if (data & 0x01) {
      gohi(MDATA);
    } 
    else {
      golo(MDATA);
    }
    /* wait for clock cycle */
    while (digitalRead(MCLK) == LOW)
      ;
    while (digitalRead(MCLK) == HIGH)
      ;
    parity = parity ^ (data & 0x01);
    data = data >> 1;
  }  
  /* parity */
  if (parity) {
    gohi(MDATA);
  } 
  else {
    golo(MDATA);
  }
  while (digitalRead(MCLK) == LOW)
    ;
  while (digitalRead(MCLK) == HIGH)
    ;
  /* stop bit */
  gohi(MDATA);
  delayMicroseconds(50);
  while (digitalRead(MCLK) == HIGH)
    ;
  /* wait for mouse to switch modes */
  while ((digitalRead(MCLK) == LOW) || (digitalRead(MDATA) == LOW))
    ;
  /* put a hold on the incoming data. */
  golo(MCLK);
  //  Serial.print("done.\n");
}
/*--------------------------------------------------------------------*/
char Minitel::mouse_read(void)
{
  char data = 0x00;
  int i;
  char bit = 0x01;

  //  Serial.print("reading byte from mouse\n");
  /* start the clock */
  gohi(MCLK);
  gohi(MDATA);
  delayMicroseconds(50);
  while (digitalRead(MCLK) == HIGH)
    ;
  delayMicroseconds(5);  /* not sure why */
  while (digitalRead(MCLK) == LOW) /* eat start bit */
    ;
  for (i=0; i < 8; i++) {
    while (digitalRead(MCLK) == HIGH)
      ;
    if (digitalRead(MDATA) == HIGH) {
      data = data | bit;
    }
    while (digitalRead(MCLK) == LOW)
      ;
    bit = bit << 1;
  }
  /* eat parity bit, which we ignore */
  while (digitalRead(MCLK) == HIGH)
    ;
  while (digitalRead(MCLK) == LOW)
    ;
  /* eat stop bit */
  while (digitalRead(MCLK) == HIGH)
    ;
  while (digitalRead(MCLK) == LOW)
    ;

  /* put a hold on the incoming data. */
  golo(MCLK);
  return data;
}


/*--------------------------------------------------------------------*/
void Minitel::mouse_init()
{
  gohi(MCLK);
  gohi(MDATA);
  //  Serial.print("Sending reset to mouse\n");
  mouse_write(0xff);
  mouse_read();  /* ack byte */
  //  Serial.print("Read ack byte1\n");
  mouse_read();  /* blank */
  mouse_read();  /* blank */
  //  Serial.print("Sending remote mode code\n");
  mouse_write(0xf0);  /* remote mode */
  mouse_read();  /* ack */
  //  Serial.print("Read ack byte2\n");
  delayMicroseconds(100);
}
/*--------------------------------------------------------------------*/
void Minitel::mouse()
{
  /* get a reading from the mouse */
  mouse_write(0xeb);  /* give me data! */
  mouse_read();      /* ignore ack */
  mstat = mouse_read();
  mx = mouse_read();
  my = mouse_read();
  /* send the data back up */
  if (mx > 0) { //test le retour à la ligne
    xCursor = xCursor+1;
    moveCursorXY(xCursor, yCursor);}
  if (mx < 0) { //test le retour à la ligne
    xCursor = xCursor-1;
    moveCursorXY(xCursor, yCursor);}
  if (my > 0) { //test le retour à la ligne
    yCursor = yCursor-1;
    moveCursorXY(xCursor, yCursor);}
  if (my < 0) { //test le retour à la ligne
    yCursor = yCursor+1;
    moveCursorXY(xCursor, yCursor);
  }
  delay(75);  /* twiddle */
  bool leftButton=mstat&0x01;
  bool rightButton=mstat &0x02;
  bool middleButton=mstat&0x04;
  if (dra_w == true && (leftButton == true && (( (xCursor >= 2) && (xCursor <= 39) ) && ( (yCursor >= 4) && (yCursor <= 21) ) ))) { //clic droit pour DRAW
    printChar(c);}
  if (dra_w == true && (leftButton == true && (( (xCursor >= 1) && (xCursor <= 21) ) && ( (yCursor >= 1) && (yCursor <= 2) ) ))) { //clic droit pour DRAW 
   draw();}
  if (vortext_e == true && (leftButton == true && (( (xCursor >= 1) && (xCursor <= 21) ) && ( (yCursor >= 1) && (yCursor <= 2) ) ))) { //clic droit pour DRAW 
   vortexte();}
  if (dra_w == true && (rightButton == true && (( (xCursor >= 2) && (xCursor <= 39) ) && ( (yCursor >= 4) && (yCursor <= 21) ) ))) { //clic droit pour DRAW
    print(" ");}
  if (vortext_e == true && (rightButton == true && (( (xCursor >= 2) && (xCursor <= 39) ) && ( (yCursor >= 4) && (yCursor <= 21) ) ))) { //clic droit pour DRAW
    print(" ");} // à mettre en une seule ligne avec celle du dessus?
  ///////////////////////// message d'infos colonne de droite
  if (logiciel_ON == false && (( (xCursor >= 32) && (xCursor <= 35) ) && ( (yCursor == 4) ) )) { // message d'info VORTEXTE
    moveCursorXY(13, 17);
    print("logiciel de     ");
    moveCursorXY(13, 18);
    print("texte           ");
    moveCursorXY(13, 19);
    print("                ");
    moveCursorXY(38, 4);}
  if (logiciel_ON == false && (( (xCursor >= 32) && (xCursor <= 35) ) && ( (yCursor == 11) ) )) { // message d'info DRAW
    moveCursorXY(13, 17);
    print("logiciel de     ");
    moveCursorXY(13, 18);
    print("dessin          ");
    moveCursorXY(13, 19);
    print("                ");
    moveCursorXY(38, 11);}
  if (logiciel_ON == false && (( (xCursor >= 32) && (xCursor <= 35) ) && ( (yCursor == 19) ) )) { // message d'info MARAUDER
    moveCursorXY(13, 17);
    print("jeux            ");
    moveCursorXY(13, 18);
    print("Marauder        ");
    moveCursorXY(13, 19);
    print("                ");
    moveCursorXY(38, 19);}
  //////////// message d'infos colonne de gauche
   if (logiciel_ON == false && (( (xCursor >= 4) && (xCursor <= 7) ) && ( (yCursor == 4) ) )) { // message d'info carte SD
    moveCursorXY(13, 17);
    print("lecteur de      ");
    moveCursorXY(13, 18);
    print("carte SD        ");
    moveCursorXY(13, 19);
    print("                ");
    moveCursorXY(9, 4);}
  if (logiciel_ON == false && (( (xCursor >= 4) && (xCursor <= 7) ) && ( (yCursor == 11) ) )) { // message d'info cartouche
    moveCursorXY(13, 17);
    print("chargement      ");
    moveCursorXY(13, 18);
    print("cartouche       ");
    moveCursorXY(13, 19);
    print("                ");
    moveCursorXY(9, 11);}
  if (logiciel_ON == false && (( (xCursor >= 4) && (xCursor <= 7) ) && ( (yCursor == 19) ) )) { // message d'info série
    moveCursorXY(13, 17);
    print("liaison         ");
    moveCursorXY(13, 18);
    print("série           ");
    moveCursorXY(13, 19);
    print("                ");
    moveCursorXY(9, 19);}
  ////////////////////////////////////:
  if (logiciel_ON == false && (leftButton == true && (( (xCursor >= 31) && (xCursor <= 38) ) && ( (yCursor >= 8) && (yCursor <= 14) ) ))) { //clic droit pour MENU
    draw();}
  if (logiciel_ON == false && (leftButton == true && (( (xCursor >= 31) && (xCursor <= 38) ) && ( (yCursor >= 15) && (yCursor <= 22) ) ))) { //clic droit pour MENU
    marauder();}
  if (logiciel_ON == false && (leftButton == true && (( (xCursor >= 3) && (xCursor <= 10) ) && ( (yCursor >= 1) && (yCursor <= 7) ) ))) { //clic droit pour DRAW 
   readSD();}
  if (logiciel_ON == false && (leftButton == true && (( (xCursor >= 31) && (xCursor <= 38) ) && ( (yCursor >= 1) && (yCursor <= 7) ) ))) { //clic droit pour DRAW 
   vortexte();}
  if (logiciel_ON == false && (leftButton == true && (( (xCursor >= 3) && (xCursor <= 10) ) && ( (yCursor >= 8) && (yCursor <= 14) ) ))) { //clic droit pour DRAW 
   load_cart();}
  if (logiciel_ON == false && (leftButton == true && (( (xCursor >= 3) && (xCursor <= 10) ) && ( (yCursor >= 15) && (yCursor <= 22) ) ))) { //clic droit pour DRAW 
   serie();}
  
    //if (monsterY == heroY && monsterX == heroX)
 // if (rightButton == true && (( (xCursor >= 25) && (xCursor <= 30) ) && ( (yCursor >= 5) && (yCursor <= 10) ) )) { //test le retour à la ligne
  //  print("R");}
  //if (middleButton == true) { //test le retour à la ligne
  //  print("R");}
}
/*--------------------------------------------------------------------*/
////////////////////////////////////////////////////
//   TEST mode graphique
////////////////////////////////////////////////
void Minitel::test(){  
  logiciel_ON = true;
  newScreen();
  pageMode();
  echoON();
  cursor();
  graphicMode();
  
  
}
/*--------------------------------------------------------------------*/
////////////////////////////////////////////////////
//   MONITEUR SERIE
////////////////////////////////////////////////
void Minitel::serie(){  
  logiciel_ON = true;
  seria_l = true;
  newScreen();
  scrollMode();
  echoON();
  cursor();
  println(">> TEST COMMUNICATION SERIE (en cours)");
  println("CONFIGURATION : ");  
  println("7 bit de données, 1 bit de parité paire, 1 bit de stop");
  //Serial.print("teste communication ZARDOS");
  //if(Serial.available()){
  //Serial.write(Serial.read());}
  //Serial.print("teste communication ZARDOS");
  //if(Serial.available()){
  //Serial.write(Serial.read());}
}
/*--------------------------------------------------------------------*/
////////////////////////////////////////////////////
//   GUIDE
////////////////////////////////////////////////
void Minitel::guide(){  
  logiciel_ON = true;
  newScreen();
  pageMode();
  echoOFF();
  noCursor();
  moveCursorXY(15, 1);
  print("--- GUIDE ---");
  moveCursorXY(1, 2);
  print("retour au menu : appuyez sur [SOMMAIRE]");
  hLine(1, 3, 40, CENTER);
  moveCursorXY(1, 5);
  print("ZARD-OS ou, 'Ze ARDuino Operating System', est un système d'exploitation dedié au micro-controleur compatible Arduino utilisant un Minitel comme interface homme-machine.  ");
  moveCursorXY(1, 12);
  print(":::  TOUCHES DE RACCOURCI :::");
  moveCursorXY(1, 9);
  println(" - [SOMMAIRE]   => Menu Principal");
  println(" - [ANNULATION] => Redémarrage Système");
  println(" - [GUIDE]      => Guide & Notes");
  hLine(1, 22, 40, CENTER);
  moveCursorXY(1, 24);
  print("ZARDOS version 1.0 du  : 21 Juin 2021");
  
}

/*--------------------------------------------------------------------*/
////////////////////////////////////////////////////
//   CARTOUCHE
////////////////////////////////////////////////
void Minitel::load_cart(){  
  logiciel_ON = true;
  newScreen();
  print("chargement de la cartouche...");
  delay(1000);
  pageMode();
  echoON();
  cursor();
  cart_in = true;
  digitalWrite(cart_ground, HIGH);
  digitalWrite(cart_Tx, HIGH);
  digitalWrite(cart_Rx, HIGH);
  digitalWrite(cart_Vin, HIGH);
  
}
/*--------------------------------------------------------------------*/
/////////////////////////////////////////////
//      remise à zéro des opérateurs booléens
////////////////////////////////////////////

void Minitel::bool_box(){
  logiciel_ON = false;
  cart_in = false;
  dra_w = false;
  vortext_e = false; // vortexte inactif au lancement
  mous_e = false; //souris inactive par défaut
  cartridge_in = false; // cartouche absente par défaut
  cartridge_take_over = false;
  maraude_r = false;
  read_SD = false;
}

/*--------------------------------------------------------------------*/
////////////////////////////////////////////////////
//   ECRAN APPLICATION DE TEXTE
////////////////////////////////////////////////
void Minitel::vortexte(){  
  logiciel_ON = true;
  newScreen();
  pageMode();
  echoON();
  cursor();
  vortext_e = true;
  moveCursorXY(12, 1);
  print("--- VORTEXTE ---");
  moveCursorXY(1, 2);
  print("[effacement écran] - gomme = clic droit");
  hLine(1, 3, 40, CENTER);
  moveCursorXY(1, 5);
}
/*--------------------------------------------------------------------*/

////////////////////////////////////////////////////
//   ECRAN APPLICATION DE DESSIN
////////////////////////////////////////////////
void Minitel::draw(){  
  logiciel_ON = true;
  newScreen();
  pageMode();
  echoOFF();
  cursor();
  dra_w = true;
  moveCursorXY(14, 1);
  print("--- DRAW ---");
  moveCursorXY(1, 2);
  print("[effacement écran] - gomme = clic droit");
  hLine(1, 3, 40, CENTER);
  hLine(1, 22, 40, CENTER);
  moveCursorXY(1, 24);
  print("caractère selectionné :");
  moveCursorXY(20, 12);
}
/*--------------------------------------------------------------------*/
///////////////////////////////////////////////////
//     JEUX MARAUDER
///////////////////////////////////////////////
void Minitel::marauder(){  
  logiciel_ON = true;
  newScreen();
  pageMode();
  echoOFF();
  noCursor();
  maraude_r = true;
  marauder_monsterX = 20;
  marauder_monsterY = 6;
  marauder_heroX = 20;
  marauder_heroY = 20;
  moveCursorXY(12, 1);
  print("--- MARAUDER ---");
  moveCursorXY(1, 2);
  print("");
  hLine(1, 3, 40, CENTER);
  moveCursorXY(1, 4);
  print("SCORE : "); 
  print(String(marauder_score)); // 
  moveCursorXY(1, 5);
  print("LIFE : ");
  print(String(marauder_life));
  moveCursorXY(1, 7);
  print("- [REPETITION] => DROITE ");
  moveCursorXY(1, 8);
  print("- [RETOUR]     => GAUCHE ");
  moveCursorXY(1, 9);
  print("- [ENVOI]      => ATTAQUE ");
  hLine(1, 22, 40, CENTER); 
  moveCursorXY(12, 21);
  print(")");
  moveCursorXY(marauder_heroX, marauder_heroY);
  print("0");
  moveCursorXY(28, 21);
  print("(");
  moveCursorXY(marauder_monsterX, marauder_monsterY);
  print("M");
  bool maraude_r = true;
  
}

/*--------------------------------------------------------------------*/
void Minitel::marauder_move(){
     marauder_sabreY = 0;
     //delay(marauder_speed);
     moveCursorXY(marauder_monsterX, marauder_monsterY);
     deleteChars(1);
     marauder_monsterY = (marauder_monsterY+1);
     if (marauder_monsterX == marauder_heroX){                // si le monstre et le héro sont alignés le monstre descend tout droit
     marauder_monsterX = marauder_monsterX;}
     if (marauder_monsterX < marauder_heroX){                 // si le monstre est à gauche du héro, il descend vers la droite
     marauder_monsterX = marauder_monsterX+random(3);}
     if (marauder_monsterX > marauder_heroX){                 // si le monstre est à droite du héro, il descend vers la gauche 
     marauder_monsterX = marauder_monsterX-random(3);}
     moveCursorXY(marauder_monsterX, marauder_monsterY);
     print("M");
     marauder_test();
     
}
/*--------------------------------------------------------------------*/
void Minitel::marauder_test(){
     
     /*if ((marauder_monsterX == marauder_sabreX  ) && (marauder_monsterY == marauder_sabreY)){
     marauder_win();}*/
     /*if (marauder_heroX < 8){
     marauder_heroX =8;}
     if (marauder_heroX > 16){
     marauder_heroX =16;}*/
     if ((marauder_monsterY == marauder_heroY) && (marauder_monsterX == marauder_heroX)){
     marauder_loose();}
     //if ((marauder_monsterX == monster_heroX  ) && (marauder_monsterY == marauder_sabreY)){
     //marauder_win();}
     if (marauder_monsterY > marauder_heroY+1){
     marauder_win();}
     if (marauder_life == 0){
     marauder_game_over();}
}  
/*--------------------------------------------------------------------*/
void Minitel::marauder_loose(){
     println("  you loose...");
     marauder_life = (marauder_life-1);
     delay(1000);
     marauder();
}
/*--------------------------------------------------------------------*/
void Minitel::marauder_win(){
     println("   you win!");
     marauder_score = (marauder_score+1);
     marauder_speed = (marauder_speed/2);
     delay(1000);
     marauder();
}

/*--------------------------------------------------------------------*/
void Minitel::marauder_game_over(){
     println("    GAME OVER");
     delay(2000);
     clearLine();
     moveCursorXY(20, 12);
     println("  please try again!");
     delay(2000);
     marauder_score = 3;
     marauder_life = 3;
     marauder();
}
/*--------------------------------------------------------------------*/
//////////////////////////////////////////////////////////
//   RESET clavier de l'Arduino par touche ANNULATION
//////////////////////////////////////////////////////////

void Minitel::pushReset() { 
  // active la broche en sortie (OUTPUT)  
  pinMode(resetPin, OUTPUT); 
  // Déactive le reset forçant la sortie au niveau bas 
  digitalWrite(resetPin, LOW);
}

/*--------------------------------------------------------------------*/
/////////////////////////////////////////////////////////
//    ROUTINE DE GESTION DU CLAVIER
////////////////////////////////////////////////////////
void Minitel::keyboard(){
unsigned long key = getKeyCode();
    
 if (key != 0) // une touche a été pressée
  { 
     if (key == key_A)
     c = (65);
     if (key == key_B)
     c = (char (66));
     if (key == key_C)
     c = (char (67));
     if (key == key_D)
     c = (char (68));
     if (key == key_E)
     c = (char (69));
     if (key == key_F)
     c = (char (70));
     if (key == key_G)
     c = (char (71));
     if (key == key_H)
     c = (char (72));
     if (key == key_I)
     c = (char (73));
     if (key == key_J)
     c = (char (74));
     if (key == key_K)
     c = (char (75));
     if (key == key_L)
     c = (char (76));
     if (key == key_M)
     c = (char (77));
     if (key == key_N)
     c = (char (78));
     if (key == key_O)
     c = (char (79));
     if (key == key_P)
     c = (char (80));
     if (key == key_Q)
     c = (char (81));
     if (key == key_R)
     c = (char (82));
     if (key == key_S)
     c = (char (83));
     if (key == key_T)
     c = (char (84));
     if (key == key_U)
     c = (char (85));
     if (key == key_V)
     c = (char (86));
     if (key == key_W)
     c = (char (87));
     if (key == key_X)
     c = (char (88));
     if (key == key_Y)
     c = (char (89));
     if (key == key_Z)
     c = (char (90));
     if (key == key_EXCLAM)
     c = (char (33));
     if (key == key_QUOTE)
     c = (char (34));
     if (key == key_HASH)
     c = (char (35));
     if (key == key_DOLLAR)
     c = (char (36));
     if (key == key_PERCENT)
     c = (char (37));
     if (key == key_AND)
     c = (char (38));
     if (key == key_AP)
     c = (char (39));
     if (key == key_par_o)
     c = (char (40));
     if (key == key_par_c)
     c = (char (41));
     if (key == key_STAR)
     c = (char (42));
     if (key == key_PLUS)
     c = (char (43));
     if (key == key_VIRG)
     c = (char (44));
     if (key == key_MOINS)
     c = (char (45));
     if (key == key_DOT)
     c = (char (46));
     if (key == key_SLASH)
     c = (char (47));
     if (key == key_0)
     c = (char (48));
     if (key == key_1)
     c = (49);
     if (key == key_2)
     c = (char (50));
     if (key == key_3)
     c = (char (51));
     if (key == key_4)
     c = (char (52));
     if (key == key_5)
     c = (char (53));
     if (key == key_6)
     c = (char (54));
     if (key == key_7)
     c = (char (55));
     if (key == key_8)
     c = (char (56));
     if (key == key_9)
     c = (char (57));
     if (key == key_2P)
     c = (char (58));
     if (key == key_PV)
     c = (char (59));
     if (key == key_INF_A)
     c = (char (60));
     if (key == key_EGAL)
     c = (char (61));
     if (key == key_SUP_A)
     c = (char (62));
     if (key == key_QUESTION)
     c = (char (63));
     if (key == ENVOI)
     c = (char (13));
     if (key == RETOUR)
     c = (char (13));
     if (key == SP)
     c = (char (32));
     if (key == DEL)
     c = (char (127));
     //if (key == FLECHE_GAUCHE)
     //print("test");
     //minitel.printSpecialChar(0x2F);
     //minitel.printSpecialChar(0x2F);
     /*if (key == FLECHE_DROITE)
     Serial.write(0x19);
     minitel.printSpecialChar(0x2E);
     if (key == FLECHE_HAUT)
     Serial.write(0x19);
     minitel.printSpecialChar(0x2C);
     if (key == FLECHE_BAS)
     Serial.write(0x19);
     minitel.printSpecialChar(0x2D);*/
     //minitel.moveCursorDown(1);
     // Touches de fonction a définir
     //if (key == REPETITION)
     //if (key == GUIDE)
     if (key == ANNULATION)
     pushReset();
     //if (key == SOMMAIRE)
     //OS_menu();
     //if (key == BS)
     //c = (char (0x08));
  // essai de backspace, fonctionne mais n'efface pas le caractère réellement tapé dans BASIC
     //if (key == SUITE)
     //if (key == CONNEXION)
  }
  if ((dra_w == true) && (key != 0)){
     moveCursorXY(30, 24);
     print("[ ");
     printChar(c);
     print(" ]");
     moveCursorXY(xCursor, yCursor);}
  if ((maraude_r == true) && (key == REPETITION)){ // mouvement à droite
     moveCursorXY(marauder_heroX , marauder_heroY);
     clearLine();
     moveCursorXY(marauder_heroX+1 , marauder_heroY);
     print("0");
     marauder_heroX = (marauder_heroX+1);}
  if ((maraude_r == true) && (key == RETOUR)){  // mouvement à gauche
     moveCursorXY(marauder_heroX , marauder_heroY);
     clearLine();
     moveCursorXY(marauder_heroX-1 , marauder_heroY);
     print("0");
     marauder_heroX = (marauder_heroX-1);}
  if (marauder_heroX < 14){
     marauder_heroX = marauder_heroX+2;}
  if (marauder_heroX > 26){
     marauder_heroX = marauder_heroX-2;}
  if ((maraude_r == true) && (key == ENVOI)){  // mouvement à gauche
     marauder_sabreY = (marauder_heroY-1);
     marauder_sabreX = (marauder_heroX);
     moveCursorXY(marauder_sabreX , marauder_sabreY);
     print("/");
  if ((marauder_monsterX == marauder_heroX  ) && (marauder_monsterY == marauder_sabreY)){
     marauder_win();}
     moveCursorXY(marauder_heroX , marauder_heroY-1);
     deleteChars(1);
     //delay(100);
     //marauder_sabre = false;
     }
   Serial.print(c);
}
/*--------------------------------------------------------------------*/
/////////////////////////////////////////////////////////
//    LECTURE CARTE SD
////////////////////////////////////////////////////////
void Minitel::readSD(){
  logiciel_ON = true;
  read_SD = true;
  newScreen();
  println("Please insert SD card...");
  delay(5000);
  println("Initializing SD card...");
  SD.begin(53); //PIN 53 ouverture du dialogue avec la carte SD
  println("initialization done.");
  println("");
  // open the file. note that only one file can be open at a time,
  // so you have to close this one before opening another.
  File myFile;
  //File dataFile = SD.open("test.txt");
  myFile = SD.open("test.txt");
  if (myFile) {
    //Serial.println("test.txt:");

    // read from the file until there's nothing else in it:
    while (myFile.available()) {
      writeByte(myFile.read());
    }
    // close the file:
    myFile.close();
  } else {
    // if the file didn't open, print an error:
    println("error opening test.txt");
  }
}



////////////////////////////////////////////////////////////////////////
/*
   Private
*/
////////////////////////////////////////////////////////////////////////

boolean Minitel::isValidChar(byte index) {
  // On vérifie que le caractère appartient au jeu G0 (voir p.100).
  // SP (0x20) correspond à un espace et DEL (0x7F) à un pavé plein.
  if (index >= SP && index <= DEL) {
    return true;
  }
  return false;
}
/*--------------------------------------------------------------------*/

boolean Minitel::isDiacritic(unsigned char caractere) {
	String accents = "àâäèéêëîïôöùûüçÀÂÄÈÉÊËÎÏÔÖÙÛÜÇ";
	if (accents.indexOf(caractere) >= 0)
	{
		return true; 
  	}
  return false;
}
/*--------------------------------------------------------------------*/

void Minitel::writeBytesP(int n) {
  // Pn, Pr, Pc : Voir remarques p.95 et 96
  if (n<=9) {
    writeByte(0x30 + n);
  }
  else {
    writeByte(0x30 + n/10);
    writeByte(0x30 + n%10);
  }
}
/*--------------------------------------------------------------------*/

void Minitel::writeBytesPRO(int n) {  // Voir p.134
  writeByte(ESC);  // 0x1B
  switch (n) {
    case 1 : writeByte(0x39); break;
    case 2 : writeByte(0x3A); break;
    case 3 : writeByte(0x3B); break;
  }
}
/*--------------------------------------------------------------------*/

int Minitel::workingSpeed() {
  int bauds = -1;
  while (!mySerial);  // On attend que le port soit sur écoute.
  unsigned long time = millis();
  unsigned long duree = 0;
  unsigned long trame = 0;  // 32 bits = 4 octets
  // On se donne 1000 ms pour récupérer une trame exploitable
  while ((trame >> 8 != 0x1B3A75) && (duree < 1000)) {  // Voir p.141
	if (mySerial.available() > 0) {
      trame = (trame << 8) + readByte();
      //Serial.println(trame, HEX);
    }
    duree = millis() - time;
  }
  switch (trame) {
    case 0x1B3A7552 : bauds =  300; break;
    case 0x1B3A7564 : bauds = 1200; break;
    case 0x1B3A7576 : bauds = 4800; break;
    case 0x1B3A757F : bauds = 9600; break;  // Pour le Minitel 2 seulement
  }
  return bauds;	
}
/*--------------------------------------------------------------------*/

byte Minitel::workingMode() {  // Voir p.143
  // On récupère notamment les 4 bits de poids faibles suivants : ME PC RL F
  // ME : mode minuscules / majuscules du clavier (1 = minuscule)
  // PC : PCE (1 = actif)
  // RL : rouleau (1 = actif)
  // F  : format d'écran (1 = 80 colonnes)
  while (!mySerial);  // On attend que le port soit sur écoute.
  unsigned long trame = 0;  // 32 bits = 4 octets  
  while (trame >> 8 != 0x1B3A73) {
    if (mySerial.available() > 0) {
      trame = (trame << 8) + readByte();
      //Serial.println(trame, HEX);
    }
  }
  return (byte) trame;
}
/*--------------------------------------------------------------------*/

byte Minitel::workingKeyboard() {  // Voir p.142
  // On récupère notamment les 3 bits de poids faibles suivants : C0 0 Eten
  // Eten : mode étendu (1 = actif)
  // C0   : codage en jeu C0 des touches de gestion du curseur (1 = actif)
  while (!mySerial);  // On attend que le port soit sur écoute.
  unsigned long trame = 0;  // 32 bits = 4 octets  
  while (trame != 0x1B3B7359) {
    if (mySerial.available() > 0) {
      trame = (trame << 8) + readByte();
      //Serial.println(trame, HEX);
    }
  }
  while (!mySerial.available()>0);  // Indispensable
  return readByte();
}
/*--------------------------------------------------------------------*/

unsigned long Minitel::getCursorXY() {  // Voir p.98
  // Demande
  writeByte(ESC);
  writeByte(0x61);
  // Réponse
  while (!mySerial);  // On attend que le port soit sur écoute.
  unsigned long trame = 0;  // 32 bits = 4 octets  
  while (trame >> 16 != US) {
    if (mySerial.available() > 0) {
      trame = (trame << 8) + readByte();
    }
  }
  return trame;
}
/*--------------------------------------------------------------------*/
