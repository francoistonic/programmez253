cartouche BASIC

Cette version du programme peut-être utilisé comme cartouche pour le système
ZARDOS, ou bien être utilisé tel quel directement sur le Minitel en branchant 
les fil :
Rx => Tx
Tx => Rx
GND => GND
