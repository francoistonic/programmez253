import serial, os, tty, sys, termios, errno, time, math, subprocess, shlex
import snake
from threading import Thread, RLock
from queue import Queue
from PIL import Image
from pydbg import dbg

WIDTH = 40
HEIGHT = 24
BAUD = 1200

HISTORY_SIZE = 1000

FG_COLORS = [b"\x1b\x40", b"\x1b\x44", b"\x1b\x41", b"\x1b\x45", b"\x1b\x42", b"\x1b\x46", b"\x1b\x43", b"\x1b\x47"]
BG_COLORS = [b"\x1b\x50", b"\x1b\x54", b"\x1b\x51", b"\x1b\x55", b"\x1b\x52", b"\x1b\x56", b"\x1b\x53", b"\x1b\x57"]
WHITE = FG_COLORS[-1]
BLACK = BG_COLORS[0]

MODE_GRAPH = b"\x0e"
MODE_TEXT = b"\x0f"

BLINK = b"\x1b\x48"
BLINK_NO = b"\x1b\x49"

FONT_SIZE_1 = b"\x1b\x4c"
FONT_SIZE_2H = b"\x1b\x4d"
FONT_SIZE_2W = b"\x1b\x4e"
FONT_SIZE_2 = b"\x1b\x4f"

BELL = b"\x07"

CURSOR_LEFT = b"\x08"
CURSOR_RIGHT = b"\x09"
CURSOR_DOWN = b"\x0a"
CURSOR_UP = b"\x0b"

CURSOR_VISIBLE = b"\x11"
CURSOR_INVISIBLE = b"\x14"

CLEAR_SCREEN = b"\x0c"

VIDEO_INV = b"\x1b\x5d"
VIDEO_NORMAL = b"\x1b\x5c"

SPECIAL_CONNECT = b"\x13Y\x13Y"
SPECIAL_REPEAT = b"\x13C"
SPECIAL_CANCEL = b"\x13E"
SPECIAL_RETURN = b"\x13B"
SPECIAL_SUMMARY = b"\x13F"
SPECIAL_CORRECT = b"\x13G"
SPECIAL_NEXT = b"\x13H"
SPECIAL_GUIDE = b"\x13D"
SPECIAL_SEND = b"\x13A"

def init_ser():
	ser = serial.Serial("/dev/ttyACM0")
	ser.baudrate = BAUD
	return ser

def goto(x, y):
	return bytes([0x1f, y+64, x+64])

# TODO complex substrings
def compress(s):
	if len(s) == 0:
		return s
	res = s[0:1]
	last = s[0]
	n = 0 # number of chars in cache
	m = 1 # number of chars written
	
	for c in s[1:]:
		if c == last:
			n += 1
		else:
			while n > 2:
				nn = min(m, min(191, n))
				if nn > 2:
					res += bytes([18, 64 + nn])
					n -= nn
					m += nn
				elif nn > 0:
					res += bytes([last])
					n -= 1
					m += 1
			if n > 0:
				res += bytes([last]*n)
			
			res += bytes([c])
			last = c
			n = 0
			m = 1
	
	while n > 2:
		nn = min(m, min(191, n))
		if nn > 2:
			res += bytes([18, 64 + nn])
			n -= nn
			m += nn
		elif nn > 0:
			res += bytes([last])
			n -= 1
			m += 1
	if n > 0:
		res += bytes([last]*n)
	
	return res

def __test_compress():
	assert dbg(compress(bytes([1]*11))) == bytes([1, 1, 1, 18, 64+3, 18, 64+5])

def sanitize_to_minitel(s):
	r = b""
	lc = None
	for c in s:
		if lc == 0x1b and c == 0x63:
			r += b"\x0c"
			lc = None
		elif lc == None and c == 0x1b:
			lc = c
		elif lc == None and c == 0x0a:
			r += b"\r\n"
		#elif lc == None and c == 0x07:
		#	pass
		elif lc:
			r += bytes([lc, c])
			lc = None
		else:
			r += bytes([c])
	print(r)
	return r

def run_fifo(ser):
	try:
		os.mkfifo("/tmp/minitel")
	except FileExistsError:
		True
	os.chmod("/tmp/minitel", 0o777)
	
	fifo_txt = os.open("/tmp/minitel", os.O_RDWR)
	
	lc = None
	
	try:
		while True:
			c = os.read(fifo_txt, 1)
			if lc == b"\x1b" and c == b"c":
				c = b"\x0c"
				lc = None
			elif lc == None and c == b"\x1b":
				lc = c
				c = b""
			elif lc == None and c == b"\n":
				c = b"\r\n"
			elif lc == None and c == b"\x07":
				c = b""
			elif lc:
				c = lc + c
				lc = None
			ser.write(c)
			time.sleep(0.01)
	except KeyboardInterrupt:
		exit()

def sine(ser):
	ser.write(MODE_TEXT+CLEAR_SCREEN+BLINK_NO+WHITE+MODE_GRAPH)
	y = 0
	for x in range(0, 40):
		v = int(math.cos(x*2*math.pi/40)*11+HEIGHT/2)
		if v > y:
			ser.write(b"\x0a"*(v-y))
		if v < y:
			ser.write(b"\x0b"*(y-v))
		y = v
		ser.write(bytes([0b01111111]))
	ser.write(b"\x0f")

def circle(ser):
	ser.write(MODE_TEXT+CLEAR_SCREEN+BLINK_NO+WHITE)
	x = 0
	y = 0
	N = 80
	for t in range(0, N):
		a = t*math.pi*2/N
		vx = int(math.cos(a)*11+WIDTH/2)
		vy = int(math.sin(a)*11+HEIGHT/2)
		if vy > y:
			ser.write(b"\x0a"*(vy-y))
		if vy < y:
			ser.write(b"\x0b"*(y-vy))
		if vx > x:
			ser.write(b"\x09"*(vx-x-1))
		if vx <= x:
			ser.write(b"\x08"*(x-vx+1))
		x = vx
		y = vy
		ser.write(bytes([0b01111111]))
	ser.write(b"\x08"*(x+1))
	ser.write(BLINK)
	for x in range(0, 40):
		v = int(math.sin(x*2*math.pi/40)*11+HEIGHT/2)
		if v > y:
			ser.write(b"\x0a"*(v-y))
		if v < y:
			ser.write(b"\x0b"*(y-v))
		y = v
		ser.write(bytes([0b01111111]))
	ser.write(MODE_TEXT)

def draw_image(ser, filename, x, y, size=(WIDTH, HEIGHT), inv=False):
	img = Image.open(filename)
	img = img.resize(size)
	
	pixels = img.getdata()
	w = img.size[0]
	if w % WIDTH == 0:
		w = WIDTH*HEIGHT # avoid newline when image naturally wraps
	b = b""
	i = 0
	for pixel in pixels:
		if type(pixel) == tuple:
			b += bytes([0b01111111 if (sum(pixel[:3]) > 382)^inv else 0b00100000])
		else:
			b += bytes([0b01111111 if (pixel > 0.5)^inv else 0b00100000])
		i += 1
		if i == 2*w:
			i = 0
			b += MODE_TEXT+b"\r\n"+MODE_GRAPH
	ser.write(compress(b))

def charpix(subline, col):
	if subline == 0:
		if col == 0: return 1<<0
		return 1<<1
	if subline == 1:
		if col == 0: return 1<<2
		return 1<<3
	if col == 0: return 1<<4
	return 1<<6

def mean(l):
	return sum(l) / len(l)

def map_color(pixels, inv=True):
	if type(pixels[0]) == tuple or type(pixels[0]) == list:
		for i in range(len(pixels)):
			pixels[i] = mean(pixels[i])
	pixel = mean(pixels)
	shade = 6-round(pixel / 255 * 6)
	return FG_COLORS[shade]

def draw_image_sub(ser, filename, x, y, size=None, inv=False, thres=0.5):
	img = Image.open(filename)
	if size:
		img = img.resize(size)
	
	pixels = img.getdata()
	w = img.size[0]
	print(w)
	if w//2 % WIDTH == 0:
		w = WIDTH*HEIGHT # avoid newline when image naturally wraps
	b = b""
	i = 0
	line = [0b00100000] * (w//2)
	colors = [[] for i in range(w//2)]
	last_color = FG_COLORS[-1]
	subline = 0
	print(len(pixels))
	for pixel in pixels:
		colors[i//2].append(pixel[:3])
		if type(pixel) == tuple:
			if (sum(pixel[:3]) > 765*thres)^inv:
				line[i//2] += charpix(subline, i%2)
		else:
			if (pixel > thres)^inv:
				line[i//2] += charpix(subline, i%2)
		i += 1
		if i == w:
			i = 0
			subline += 1
		if subline == 3:
			print(line)
			for j in range(w//2):
				color = map_color(colors[j])
				if color != last_color:
					last_color = color
					b += color
				b += bytes([line[j]])
			b += MODE_TEXT+b"\r\n"+MODE_GRAPH
			subline = 0
			line = [0b00100000] * (w//2)
			colors = [[] for i in range(w//2)]
	ser.write(compress(b))

def clear_screen(ser):
	ser.write(CLEAR_SCREEN)

def prompt():
	return os.getlogin()+("#" if os.geteuid() == 0 else "$")+" "

def exec_cmd(cmd):
	return subprocess.getoutput(cmd)

class FromMinitel(Thread):
	def __init__(self, ser, queue):
		Thread.__init__(self)
		self.ser = ser
		self.queue = queue
		
		self.rewrite = True
		self.work = True
	
	def run(self):
		lc = None
		while self.work:
			c = self.ser.read()
			print(c)
			if c == b"\x13":
				lc = c
			else:
				if lc == b"\x13":
					if c == b"A":
						if self.rewrite:
							ser.write(b"\r\n")
						self.queue.put(b"\n")
					elif c == b"B":
						self.queue.put(SPECIAL_RETURN)
					elif c == b"E":
						self.queue.put(SPECIAL_CANCEL)
					elif c == b"G":
						self.queue.put(SPECIAL_CORRECT)
					elif c == b"H":
						self.queue.put(SPECIAL_NEXT)
					lc = None
				else:
					nc = c.swapcase()
					if self.rewrite:
						ser.write(CURSOR_LEFT+nc)
					self.queue.put(nc)
	
	def stop(self):
		self.work = False
	
	def set_rewrite(self, rewrite):
		self.rewrite = rewrite

class ToMinitel(Thread):
	def __init__(self, ser, queue):
		Thread.__init__(self)
		self.ser = ser
		self.queue = queue
		self.work = True
	
	def run(self):
		while self.work:
			c = self.queue.get()
			print(c)
			if c == None:
				continue
			if type(c) == str:
				c = c.encode()
			c = sanitize_to_minitel(c)
			self.ser.write(c)
	
	def stop(self):
		self.work = False
		self.queue.put(None)

class Shell(Thread):
	def __init__(self, queue_from_minitel, queue_to_minitel, set_rewrite):
		Thread.__init__(self)
		self.queue_from_minitel = queue_from_minitel
		self.queue_to_minitel = queue_to_minitel
		self.set_rewrite = set_rewrite
		self.work = True
	
	def run(self):
		self.queue_to_minitel.put(prompt())
		history = [""]
		history_pos = 0
		while self.work:
			c = self.queue_from_minitel.get()
			if c == None:
				continue
			elif c == SPECIAL_CANCEL:
				self.queue_to_minitel.put("^C\n"+prompt())
				history[history_pos] = ""
			elif c == SPECIAL_CORRECT:
				self.queue_to_minitel.put(b"\x1b\x63"+(prompt()+history[history_pos]).encode())
			elif c == SPECIAL_RETURN:
				old_len = len(history[history_pos])
				self.queue_to_minitel.put(CURSOR_LEFT*len(history[history_pos]))
				history_pos = max(0, history_pos-1)
				self.queue_to_minitel.put(history[history_pos])
				if old_len > len(history[history_pos]):
					self.queue_to_minitel.put(b" "*(old_len-len(history[history_pos]))+CURSOR_LEFT*(old_len-len(history[history_pos])))
			elif c == SPECIAL_NEXT:
				old_len = len(history[history_pos])
				self.queue_to_minitel.put(CURSOR_LEFT*len(history[history_pos]))
				history_pos = min(len(history)-1, history_pos+1)
				self.queue_to_minitel.put(history[history_pos])
				if old_len > len(history[history_pos]):
					self.queue_to_minitel.put(b" "*(old_len-len(history[history_pos]))+CURSOR_LEFT*(old_len-len(history[history_pos])))
			elif c == b"\n":
				if history[history_pos] == "":
					self.queue_to_minitel.put(prompt())
				else:
					self.queue_to_minitel.put(self.exec_cmd(history[history_pos])+prompt())
					if history_pos == len(history)-1:
						history.append("")
					if len(history) >= HISTORY_SIZE:
						history.pop(0)
					history_pos = len(history)-1
				history[history_pos] = ""
			else:
				history[history_pos] += c.decode()
	
	def exec_cmd(self, cmd):
		args = shlex.split(cmd)
		print(args)
		if len(args) == 1:
			if args[0] == "snake":
				snake.run(self, self.queue_from_minitel, self.set_rewrite)
				return "\n"
		if len(args) == 2:
			if args[0] == "cd":
				path = os.path.expanduser(os.path.expandvars(args[1]))
				print(path)
				os.chdir(path)
				return ""
		return exec_cmd(cmd)+"\n"
	
	def stop(self):
		self.work = False
		self.queue_from_minitel.put(None)
	
	def write(self, w):
		self.queue_to_minitel.put(w)

def run_fifo2(ser):
	ser.write(CURSOR_VISIBLE)
	
	queue_to_minitel = Queue()
	queue_from_minitel = Queue()
	
	from_minitel = FromMinitel(ser, queue_from_minitel)
	to_minitel = ToMinitel(ser, queue_to_minitel)
	shell = Shell(queue_from_minitel, queue_to_minitel, from_minitel.set_rewrite)
	
	from_minitel.start()
	to_minitel.start()
	shell.start()
	
	input("Press a key to quit...")
	to_minitel.stop()
	from_minitel.stop()
	shell.stop()
	to_minitel.join()
	from_minitel.join()
	shell.join()

def draw_palette(ser):
	for fg in FG_COLORS:
		ser.write(fg)
		for bg in BG_COLORS:
			ser.write(bg)
			ser.write(b"a")
		ser.write(b"\r\n")

if __name__ == "__main__":
	ser = init_ser()
	time.sleep(1)
	ser.write(MODE_TEXT+CLEAR_SCREEN+BLINK_NO+WHITE)
	
	run_fifo2(ser)
	
	#run_fifo(ser)
	#circle(ser)
	#ser.write(MODE_GRAPH)
	#draw_image_sub(ser, "/home/tuxmain/Images/logos/jsb.png", 0, 0, inv=True, size=(40*2-2, 24*3), thres=0.5)
	#draw_image_sub(ser, "/tmp/map.png", 0, 0, inv=True, size=(40*2-2, 24*3))


"""
bounce: correction de l'entrée minitel sur l'écran minitel

"""
