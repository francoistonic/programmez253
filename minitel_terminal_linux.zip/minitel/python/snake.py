import minitel, sys, time, random, queue

DIRECTION_LEFT = 1
DIRECTION_RIGHT = 2
DIRECTION_UP = 3
DIRECTION_DOWN = 4

CHARPIX = bytes([0b00100000|minitel.charpix(0,0)|minitel.charpix(0,1)|minitel.charpix(1,0)|minitel.charpix(1,1)|minitel.charpix(2,0)|minitel.charpix(2,1)])
CHARPIX_APPLE = bytes([0b00100000])

REDRAW_APPLE = 10

class Vector:
	def __init__(self, x, y):
		self.x = x
		self.y = y
	
	def pos(self):
		return (self.x, self.y)
	
	def __add__(self, rhs):
		return Vector(self.x+rhs.x, self.y+rhs.y)
	
	def __sub__(self, rhs):
		return Vector(self.x-rhs.x, self.y-rhs.y)
	
	def __mod__(self, rhs):
		return Vector(self.x%rhs.x, self.y%rhs.y)
	
	def __floordiv__(self, rhs):
		return Vector(self.x//rhs, self.y//rhs)
	
	def __eq__(self, rhs):
		return isinstance(rhs, Vector) and self.x == rhs.x and self.y == rhs.y
	
	def to_int(self):
		return Vector(int(self.x), int(self.y))

SCREEN_SIZE = Vector(minitel.WIDTH, minitel.HEIGHT)

def get_direction_vector(direction):
	if direction == DIRECTION_LEFT:
		return Vector(-1,0)
	if direction == DIRECTION_RIGHT:
		return Vector(1,0)
	if direction == DIRECTION_UP:
		return Vector(0,-1)
	if direction == DIRECTION_DOWN:
		return Vector(0,1)
	return Vector(0,0)

def turn_right(direction):
	if direction == DIRECTION_LEFT:
		return DIRECTION_UP
	if direction == DIRECTION_RIGHT:
		return DIRECTION_DOWN
	if direction == DIRECTION_UP:
		return DIRECTION_RIGHT
	if direction == DIRECTION_DOWN:
		return DIRECTION_LEFT

def turn_left(direction):
	if direction == DIRECTION_LEFT:
		return DIRECTION_DOWN
	if direction == DIRECTION_RIGHT:
		return DIRECTION_UP
	if direction == DIRECTION_UP:
		return DIRECTION_LEFT
	if direction == DIRECTION_DOWN:
		return DIRECTION_RIGHT

def spiral(length):
	shape = [SCREEN_SIZE//2]
	direction = random.choice([DIRECTION_DOWN, DIRECTION_LEFT, DIRECTION_RIGHT, DIRECTION_UP])
	turn = random.choice([turn_left, turn_right])
	rem = 1
	next_rem = 2
	next_inc = 2
	for i in range(length):
		shape.append(shape[-1]+get_direction_vector(direction))
		rem -= 1
		if rem == 0:
			direction = turn(direction)
			rem = next_rem
			next_inc -= 1
			if next_inc == 0:
				next_rem += 1
	return shape

class Snake:
	def __init__(self, output, length=20):
		self.output = output
		self.length = length
		self.parts = [SCREEN_SIZE//2]
		self.direction = DIRECTION_DOWN
		self.apple = None
		self.redraw_apple = 0
		self.sweep_pos = Vector(0, 0)
	
	def draw_apple(self):
		self.output.write(minitel.goto(*self.apple.pos())+minitel.VIDEO_INV+b"A"+minitel.VIDEO_NORMAL)
		self.redraw_apple = 0
	
	def place_apple(self):
		self.apple = Vector(random.randint(0,SCREEN_SIZE.x-1), random.randint(0,SCREEN_SIZE.y-1))
		self.draw_apple()
	
	def sweep_one(self):
		if not self.sweep_pos in self.parts and self.sweep_pos != self.apple:
			self.output.write(minitel.goto(*self.sweep_pos.pos())+b" ")
		self.sweep_pos.x += 1
		if self.sweep_pos.x >= SCREEN_SIZE.x:
			self.sweep_pos.x = 0
			self.sweep_pos.y = (self.sweep_pos.y+1)%SCREEN_SIZE.y
	
	def step(self):
		head_pos = (self.parts[-1] + get_direction_vector(self.direction))%SCREEN_SIZE
		
		if head_pos in self.parts:
			self.output.write(minitel.BELL)
			return True
		
		self.parts.append(head_pos)
		self.output.write(minitel.goto(*self.parts[-1].pos())+CHARPIX)
		if self.length == 0:
			self.output.write(minitel.goto(*self.parts[0].pos())+b" ")
			self.parts.pop(0)
		else:
			self.length -= 1
		
		if None == self.apple:
			self.place_apple()
		elif self.parts[-1] == self.apple:
			self.parts.append((self.parts[-1] + get_direction_vector(self.direction))%SCREEN_SIZE)
			self.place_apple()
		elif self.redraw_apple >= REDRAW_APPLE:
			self.draw_apple()
		self.redraw_apple += 1
		
		return False

def run(output, input_queue, set_rewrite):
	set_rewrite(False)
	output.write(minitel.CLEAR_SCREEN+minitel.CURSOR_INVISIBLE+minitel.BLINK_NO+minitel.MODE_GRAPH+minitel.WHITE)
	snake = Snake(output)
	
	work = True
	pause = False
	while work:
		while True:
			try:
				entry = input_queue.get_nowait()
				if entry == b"q":
					work = False
					break
				elif entry == b"p":
					pause = not pause
				elif entry == b"2" and snake.direction != DIRECTION_DOWN:
					snake.direction = DIRECTION_UP
				elif entry == b"6" and snake.direction != DIRECTION_LEFT:
					snake.direction = DIRECTION_RIGHT
				elif entry == b"8" and snake.direction != DIRECTION_UP:
					snake.direction = DIRECTION_DOWN
				elif entry == b"4" and snake.direction != DIRECTION_RIGHT:
					snake.direction = DIRECTION_LEFT
			except queue.Empty:
				break
		if not work:
			break
		
		if not pause:
			if snake.step():
				time.sleep(0.5)
				break
		time.sleep(0.1)
		"""if istep % 10 == 0:
			p = random.random()
			if p > 0.875:
				snake.direction = turn_left(snake.direction)
			elif p > 0.75:
				snake.direction = turn_right(snake.direction)"""
	
	output.write(minitel.CLEAR_SCREEN+minitel.MODE_TEXT)
	set_rewrite(True)
