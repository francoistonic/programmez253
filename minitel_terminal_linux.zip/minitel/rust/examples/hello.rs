use image::Pixel;
use minitel::prelude::*;

fn main() {
	let ports = serialport::available_ports().expect("Cannot list available ports");

	println!("Available ports:");
	for port in ports.iter() {
		println!("{:?}", port);
	}
	println!();

	let mut minitel = Minitel::new(
		serialport::new(&ports.get(0).expect("No available port").port_name, 1200)
			.timeout(std::time::Duration::from_secs(10))
			.open()
			.expect("Cannot open port"),
		//std::io::stderr(),
		(40, 24),
	);
	std::thread::sleep_ms(1000);

	minitel.clear();
	let mut screen = minitel.get_screen().clone();
	/*screen.cells[25].content = ScreenCellContent::Char('H');
	screen.cells[26].content = ScreenCellContent::Char('e');
	screen.cells[27].content = ScreenCellContent::Char('l');
	screen.cells[28].content = ScreenCellContent::Char('l');
	screen.cells[29].content = ScreenCellContent::Char('o');
	screen.display_cursor = true;
	minitel.flush_screen_diff(screen.clone());
	std::thread::sleep_ms(500);
	screen.cells[405].content = ScreenCellContent::Char('W');
	screen.cells[406].content = ScreenCellContent::Char('o');
	screen.cells[406].blink = true;
	screen.cells[407].content = ScreenCellContent::Char('r');
	screen.cells[407].foreground_color = Color::C5;
	screen.cells[408].content = ScreenCellContent::Char('l');
	screen.cells[408].foreground_color = Color::WHITE;
	screen.cells[409].content = ScreenCellContent::Char('d');
	screen.cells[409].foreground_color = Color::C4;
	screen.cells[410].content = ScreenCellContent::Char('!');
	screen.cells[410].foreground_color = Color::WHITE;
	minitel.flush_screen_diff(screen.clone());*/

	screen.display_cursor = false;
	let img = image::open("examples/rust-logo.png")
		.expect("Cannot open image file")
		.grayscale();
	let mut img = img.to_luma_alpha8();
	img.pixels_mut().for_each(|pixel| {
		*pixel = image::LumaA([
			((255 - pixel.0[0]) as u16 * pixel.0[1] as u16 / 255) as u8,
			255,
		])
	});

	loop {
		let (minitel_img_size, minitel_img) = img::image_to_minitel(&img);
		println!("{minitel_img_size:?}");
		screen.write_content_rect(&minitel_img, (2, 0), minitel_img_size.0);
		minitel.flush_screen_diff(screen.clone());

		img = image::imageops::rotate90(&img);
		std::thread::sleep_ms(1000);
	}
}
