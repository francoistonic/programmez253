use minitel::prelude::*;

use std::{
	io::{Read, Write},
	process::{Command, Stdio},
	sync::{mpsc::channel, Arc, Mutex},
};

fn main() {
	let ports = serialport::available_ports().expect("Cannot list available ports");

	println!("Available ports:");
	for port in ports.iter() {
		println!("{:?}", port);
	}
	println!();

	let mut minitel = Minitel::new(
		serialport::new(&ports.get(0).expect("No available port").port_name, 1200)
			.timeout(std::time::Duration::from_secs(10))
			.open()
			.expect("Cannot open port"),
		//std::io::stderr(),
		(40, 24),
	);
	let mut minitel_input = minitel.input();
	std::thread::sleep_ms(1000);

	minitel.clear();
	let mut screen = minitel.get_screen().clone();
	screen.display_cursor = true;
	minitel.flush_screen_diff(screen);

	let mut child = Command::new("bash")
		.stdin(Stdio::piped())
		.stdout(Stdio::piped())
		.stderr(Stdio::piped())
		.env("TERM", "xterm")
		.env("LINES", "24")
		.env("COLUMNS", "30")
		.spawn()
		.unwrap();
	
	//let screen = Arc::new(Mutex::new(minitel.get_screen().clone()));
	let minitel = Arc::new(Mutex::new(minitel));

	//let (sender, receiver) = channel();
	let mut stdin = child.stdin.take().unwrap();
	std::thread::spawn({
		let minitel = minitel.clone();
		move || {
		let mut input_buf = vec![0; 32];
		let mut pending = 0usize; // received bytes that do not form a complete char yet
		let mut expected = 0usize; // bytes to receive to complete the pending char
		loop {
			if let Some(n) = minitel_input.try_read(&mut input_buf[pending..]).unwrap() {
				//println!("{:?}", &input_buf[0..n+prev_pending]);

				let prev_pending = pending;
				if n > 1 && input_buf[prev_pending + n - 2] == 25 {
					pending = 2;
					expected = 1;
				} else {
					match input_buf[prev_pending + n - 1] {
						19 => {
							pending = 1;
							expected = 1;
						}
						25 => {
							pending = 1;
							expected = 2;
						}
						_ => {
							expected = expected.saturating_sub(n);
							pending = if expected == 0 { 0 } else { pending + n };
						}
					}
				}

				let str_input = minitel_to_unix(&input_buf[0..n + prev_pending - pending]);
				{
					let mut minitel = minitel.lock().unwrap();
					let mut screen = minitel.get_screen().clone();
					minitel.get_screen_mut().cursor = screen.get_next_pos(screen.cursor, str_input.len());
					screen.write_text_clean(&str_input);
					minitel.flush_screen_diff(screen.clone());
				}
				stdin
					.write_all(
						str_input.as_bytes(),
					)
					.unwrap();
				input_buf.copy_within(n + prev_pending - pending..n + prev_pending, 0);
				//println!("{:?}", &input_buf[0..n]);
			}
			std::thread::sleep_ms(10);
		}
	}});

	let mut stdout = child.stdout.take().unwrap();
	std::thread::spawn({
		let minitel = minitel.clone();
		move || {
			let mut output_buf = vec![0; 1024];
			loop {
				let n = stdout.read(&mut output_buf).unwrap();
				{
					let mut minitel = minitel.lock().unwrap();
					let mut screen = minitel.get_screen().clone();
					screen.write_text_clean(dbg!(std::str::from_utf8(&output_buf[0..n])).unwrap());
					minitel.flush_screen_diff(screen.clone());
				}
				std::thread::sleep_ms(10);
			}
		}
	});

	let mut stderr = child.stderr.take().unwrap();
	std::thread::spawn(move || {
		let mut output_buf = vec![0; 1024];
		loop {
			let n = stderr.read(&mut output_buf).unwrap();
			{
				let mut minitel = minitel.lock().unwrap();
				let mut screen = minitel.get_screen().clone();
				screen.write_text_clean(dbg!(std::str::from_utf8(&output_buf[0..n])).unwrap());
				minitel.flush_screen_diff(screen.clone());
			}
			std::thread::sleep_ms(10);
		}
	})
	.join()
	.ok();
}

fn minitel_to_unix(s: &[u8]) -> String {
	println!("{s:?}");
	let decoded_input = std::str::from_utf8(s).unwrap();
	let mut to_ret = Vec::new();
	let mut ret = String::new();
	let mut lc = None;
	let mut lc2 = None;
	for c in decoded_input.chars() {
		println!("{c:?}");
		if let Some(lcc) = lc.take() {
			if lcc == '\u{13}' && c == 'A' {
				to_ret.push('\n');
			} else if lcc == '\u{13}' && c == 'G' {
				to_ret.push('\x08');
			} else if lcc == '\u{19}' {
				if let Some(lcc2) = lc2.take() {
					match (lcc2, c) {
						('\u{41}', 'A') => to_ret.push('À'),
						('\u{41}', 'E') => to_ret.push('È'),
						('\u{41}', 'U') => to_ret.push('Ù'),
						('\u{41}', 'a') => to_ret.push('à'),
						('\u{41}', 'e') => to_ret.push('è'),
						('\u{41}', 'u') => to_ret.push('ù'),
						('\u{42}', 'E') => to_ret.push('É'),
						('\u{42}', 'e') => to_ret.push('é'),
						('\u{43}', 'A') => to_ret.push('Â'),
						('\u{43}', 'E') => to_ret.push('Ê'),
						('\u{43}', 'I') => to_ret.push('Î'),
						('\u{43}', 'O') => to_ret.push('Ô'),
						('\u{43}', 'U') => to_ret.push('Û'),
						('\u{43}', 'a') => to_ret.push('â'),
						('\u{43}', 'e') => to_ret.push('ê'),
						('\u{43}', 'i') => to_ret.push('î'),
						('\u{43}', 'o') => to_ret.push('ô'),
						('\u{43}', 'u') => to_ret.push('û'),
						('\u{48}', 'E') => to_ret.push('Ë'),
						('\u{48}', 'I') => to_ret.push('Ï'),
						('\u{48}', 'e') => to_ret.push('ë'),
						('\u{48}', 'i') => to_ret.push('ï'),
						_ => to_ret.push(c),
					}
				} else {
					lc = Some(lcc);
					lc2 = Some(c);
				}
			} else {
				to_ret.push(lcc);
				to_ret.push(c);
			}
		} else if c == '\u{13}' {
			lc = Some('\u{13}');
		} else if c == '\u{19}' {
			lc = Some('\u{19}');
		} else if c == '^' {
			to_ret.push('|');
		} else {
			to_ret.push(c);
		}

		for c in to_ret.drain(..) {
			if c.is_lowercase() {
				for c in c.to_uppercase() {
					ret.push(c);
				}
			} else if c.is_uppercase() {
				for c in c.to_lowercase() {
					ret.push(c);
				}
			} else {
				ret.push(c);
			}
		}
	}
	ret
}
