use minitel::prelude::*;

use rand::Rng;
use std::{
	io::Read,
	sync::{Arc, Mutex},
};

#[derive(Clone)]
struct Piece {
	size: (usize, usize),
	blocks: Vec<bool>,
	color: Color,
}

impl Piece {
	fn random() -> Self {
		match rand::thread_rng().gen_range(0..6) {
			0 => Self {
				size: (3, 2),
				blocks: vec![true, false, false, true, true, true],
				color: Color::C7,
			},
			1 => Self {
				size: (3, 2),
				blocks: vec![false, false, true, true, true, true],
				color: Color::C7,
			},
			2 => Self {
				size: (3, 2),
				blocks: vec![false, true, true, true, true, false],
				color: Color::C5,
			},
			3 => Self {
				size: (3, 2),
				blocks: vec![true, true, false, false, true, true],
				color: Color::C5,
			},
			4 => Self {
				size: (2, 2),
				blocks: vec![true, true, true, true],
				color: Color::C4,
			},
			5 => Self {
				size: (1, 4),
				blocks: vec![true, true, true, true],
				color: Color::C3,
			},
			_ => unreachable!(),
		}
	}
}

struct Tetris {
	size: (usize, usize),
	board: Vec<bool>,
	falling: (usize, usize, Piece),
}

impl Tetris {
	fn new(size: (usize, usize)) -> Self {
		Self {
			size,
			board: vec![false; size.0 * size.1],
			falling: (size.0 / 2, 1, Piece::random()),
		}
	}

	fn update_screen(&mut self, screen: &mut Screen, redraw: &mut [bool]) {
		let mut to_redraw = 0;
		for ((&block, (pos, cell)), redraw) in self
			.board
			.iter()
			.zip(screen.iter_cells_mut())
			.zip(redraw.iter_mut())
		{
			if block
				|| (pos.0 >= self.falling.0
					&& pos.1 >= self.falling.1
					&& pos.0 < self.falling.0 + self.falling.2.size.0
					&& pos.1 < self.falling.1 + self.falling.2.size.1
					&& self.falling.2.blocks
						[pos.0 - self.falling.0 + self.falling.2.size.0 * (pos.1 - self.falling.1)])
			{
				cell.content = ScreenCellContent::Graph(Graph(0b01111111));
				cell.foreground_color = self.falling.2.color;
			} else {
				cell.content = ScreenCellContent::Graph(Graph(0b00100000));
			};
		}
	}

	fn step(&mut self) {
		if self.falling.1 + self.falling.2.size.1 == self.size.1 || self.is_fall_finished()
		//self.board[self.falling.0+self.size.0*(self.falling.1+1)]
		{
			for (piece_y, piece_line) in self
				.falling
				.2
				.blocks
				.chunks_exact(self.falling.2.size.0)
				.enumerate()
			{
				for (piece_x, piece_block) in piece_line.iter().enumerate() {
					self.board
						[self.falling.0 + piece_x + self.size.0 * (self.falling.1 + piece_y)] = *piece_block;
				}
			}
			self.falling = (self.size.0 / 2, 1, Piece::random());
		} else {
			self.falling.1 += 1;
		}
	}

	fn is_fall_finished(&self) -> bool {
		for (piece_y, piece_line) in self
			.falling
			.2
			.blocks
			.chunks_exact(self.falling.2.size.0)
			.enumerate()
		{
			for (piece_x, piece_block) in piece_line.iter().enumerate() {
				if *piece_block
					&& self.board
						[self.falling.0 + piece_x + self.size.0 * (self.falling.1 + piece_y + 1)]
				{
					return true;
				}
			}
		}
		false
	}
}

fn main() {
	let ports = serialport::available_ports().expect("Cannot list available ports");

	println!("Available ports:");
	for port in ports.iter() {
		println!("{:?}", port);
	}
	println!();

	let mut minitel = Minitel::new(
		serialport::new(&ports.get(0).expect("No available port").port_name, 1200)
			.timeout(std::time::Duration::from_secs(10))
			.open()
			.expect("Cannot open port"),
		//std::io::stderr(),
		(40, 24),
	);
	let mut minitel_input = minitel.input();
	std::thread::sleep_ms(1000);

	minitel.clear();
	let mut screen = minitel.get_screen().clone();

	let mut game = Tetris::new((40, 24));

	let mut input_buf = vec![0; 32];
	loop {
		if let Some(n) = minitel_input.try_read(&mut input_buf).unwrap() {
			println!("{:?}", &input_buf[0..n]);
			match &input_buf[0..n] {
				&[19, 68] => game.falling.0 = game.falling.0.saturating_sub(1),
				&[19, 65] => game.falling.0 = (game.falling.0 + 1).min(game.size.0 - 1),
				_ => {}
			}
		}
		{
			//let game = game.lock().unwrap();
			game.step();
			game.update_screen(&mut screen, &mut minitel.redraw);
		}
		minitel.flush_screen_diff(screen.clone());
		std::thread::sleep_ms(400);
	}
}
