use crate::screen::*;

use image::GenericImageView;

//pub fn image_to_minitel(image: &image::DynamicImage) -> ((usize, usize), Vec<ScreenCell>) {
pub fn image_to_minitel(
	image: &image::ImageBuffer<image::LumaA<u8>, Vec<u8>>,
) -> ((usize, usize), Vec<ScreenCell>) {
	let img_size = (image.width() as usize, image.height() as usize);
	let screen_size = (img_size.0.div_ceil(2), img_size.1.div_ceil(3));

	let mut screen = vec![
		ScreenCell {
			content: ScreenCellContent::Graph(Graph::default()),
			foreground_color: Color::WHITE,
			..Default::default()
		};
		screen_size.0 * screen_size.1
	];

	//for (img_x, img_y, pixel) in image.pixels() {
	for (img_x, img_y, image::LumaA([pixel_value, _])) in image.enumerate_pixels() {
		let (img_x, img_y) = (img_x as usize, img_y as usize);

		//let pixel_value = pixel.0.into_iter().map(|c| c as u16).sum::<u16>() / 4;
		if *pixel_value > 32 {
			let screen_x = img_x / 2;
			let screen_y = img_y / 3;
			let cell_x = img_x % 2;
			let cell_y = img_y % 3;

			let screen_cell = screen.get_mut(screen_x + screen_size.0 * screen_y).unwrap();
			let mut content = if let ScreenCellContent::Graph(graph) = screen_cell.content {
				graph
			} else {
				Graph::default()
			};
			content.0 |= Graph::get_single_pixel(cell_y, cell_x);
			//println!("{}", content.0);
			screen_cell.content = ScreenCellContent::Graph(content);
		}
	}

	(screen_size, screen)
}
