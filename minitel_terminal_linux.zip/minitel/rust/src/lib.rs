#![feature(int_roundings)]

pub mod img;
pub mod screen;

use screen::*;

use serialport::SerialPort;
use std::io::{Read, Write};
use std::sync::{Arc, Mutex};

pub struct Minitel /* <S: Read+Write+Sync+Send> */ {
	serial: Arc<Mutex<Box<dyn SerialPort>>>,
	screen: Screen,
	mode: Mode,
	inverse: bool,
	font_size: FontSize,
	foreground_color: Color,
	blink: bool,
	pub redraw: Vec<bool>,
}

impl Minitel {
	pub fn new(serial: Box<dyn SerialPort> /* serial: S */, size: (usize, usize)) -> Self {
		Self {
			serial: Arc::new(Mutex::new(serial)),
			//output,
			screen: Screen::new(size),
			mode: Default::default(),
			inverse: Default::default(),
			font_size: Default::default(),
			foreground_color: Default::default(),
			blink: Default::default(),
			redraw: vec![false; size.0 * size.1],
		}
	}

	pub fn input(&self) -> MinitelInput {
		MinitelInput {
			serial: self.serial.clone(),
		}
	}

	pub fn goto(&mut self, pos: (usize, usize)) {
		println!("goto {} {}", pos.0, pos.1);
		self.screen.cursor = pos;
		//self.serial.write_all(&[0x1f, 0x40+pos.1 as u8, 0x40+pos.0 as u8]).unwrap();
		self.serial
			.lock()
			.unwrap()
			.write_all(&[0x1f, 0x41 + pos.1 as u8, 0x41 + pos.0 as u8])
			.unwrap();
		self.mode = Mode::Text;
	}

	pub fn write_raw(&mut self, raw: &[u8]) {
		//self.serial.write_all(raw).unwrap();
		self.serial.lock().unwrap().write_all(raw).unwrap();
	}

	pub fn clear(&mut self) {
		//self.serial.write_all(&[0x0c]).unwrap();
		self.serial.lock().unwrap().write_all(&[0x0c]).unwrap();
	}

	pub fn get_screen(&self) -> &Screen {
		&self.screen
	}

	/// Screen should only be mutated this way if actual screen is mutated from outside the program
	pub fn get_screen_mut(&mut self) -> &mut Screen {
		&mut self.screen
	}

	#[allow(clippy::iter_with_drain)]
	pub fn flush_screen_diff(&mut self, new_screen: Screen) {
		assert_eq!(self.screen.size, new_screen.size);
		assert_eq!(self.screen.cells.len(), new_screen.cells.len());

		let mut buf = Vec::new();
		let mut buf_filtered = Vec::new();
		let mut to_repeat = 0u8;
		let mut mem = None;

		// TODO remove clone
		for (((pos, cell), new_cell), redraw) in self
			.screen
			.clone()
			.iter_cells()
			.zip(new_screen.cells.iter())
			.zip(self.redraw.iter())
		{
			if *redraw || (cell != new_cell && !(cell.is_empty() && new_cell.is_empty())) {
				if self.foreground_color != new_cell.foreground_color {
					self.foreground_color = new_cell.foreground_color;
					buf.extend_from_slice(&self.foreground_color.foreground());
				}
				if self.inverse != new_cell.inverse {
					self.inverse = new_cell.inverse;
					buf.extend_from_slice(&[0x1b, if self.inverse { 0x5d } else { 0x5c }]);
				}
				if self.font_size != new_cell.font_size {
					self.font_size = new_cell.font_size;
					buf.extend_from_slice(&[0x1b, self.font_size as u8]);
				}
				if self.blink != new_cell.blink {
					self.blink = new_cell.blink;
					buf.extend_from_slice(&[0x1b, if self.blink { 0x48 } else { 0x49 }]);
				}
				if self.screen.cursor != pos {
					buf.extend_from_slice(&[0x1f, 0x41 + pos.1 as u8, 0x41 + pos.0 as u8]);
					self.screen.cursor = pos;
					self.mode = Mode::Text;
				}
				if self.mode != new_cell.content.mode() {
					self.mode = new_cell.content.mode();
					buf.extend_from_slice(&[self.mode as u8]);
				}
				match new_cell.content {
					ScreenCellContent::Char(c) => {
						buf.extend_from_slice(&encode_char_to_minitel(c));
					}
					ScreenCellContent::Graph(c) => {
						buf.extend_from_slice(&[c.0]);
					}
				}
				self.screen.cursor.0 += 1;
				if self.screen.cursor.0 >= self.screen.size.0 {
					self.screen.cursor.0 %= self.screen.size.0;
					self.screen.cursor.1 += 1;
					self.screen.cursor.1 %= self.screen.size.1;
				}
			}
			for c in buf.drain(0..) {
				if let Some((mem_c, mem_nb)) = &mut mem {
					if *mem_c == c {
						to_repeat += 1;
					} else {
						if to_repeat <= 3 {
							for _ in 0..to_repeat {
								buf_filtered.push(*mem_c);
							}
						} else {
							while to_repeat > 0 {
								let repeats = to_repeat.min(*mem_nb).min(63);
								buf_filtered.extend_from_slice(&[18, 64 | repeats]);
								to_repeat -= repeats;
								*mem_nb = (*mem_nb + repeats).min(63);
							}
						}
						to_repeat = 0;
						buf_filtered.push(c);
						*mem_c = c;
						*mem_nb = 1;
					}
				} else {
					buf_filtered.push(c);
					mem = Some((c, 1));
				}
			}
			//buf_filtered.append(&mut buf);
		}
		if let Some((mem_c, mut mem_nb)) = mem {
			if to_repeat <= 3 {
				for _ in 0..to_repeat {
					buf_filtered.push(mem_c);
				}
			} else {
				while to_repeat > 0 {
					let repeats = to_repeat.min(mem_nb).min(63);
					buf_filtered.extend_from_slice(&[18, 64 | repeats]);
					to_repeat -= repeats;
					mem_nb = (mem_nb + repeats).min(63);
				}
			}
		}

		if new_screen.display_cursor != self.screen.display_cursor {
			buf_filtered.extend_from_slice(&[if new_screen.display_cursor {
				0x11
			} else {
				0x14
			}]);
		}
		if new_screen.cursor != self.screen.cursor {
			//self.goto(new_screen.cursor);
			buf_filtered.extend_from_slice(&[
				0x1f,
				0x41 + new_screen.cursor.1 as u8,
				0x41 + new_screen.cursor.0 as u8,
			]);
			self.mode = Mode::Text;
		}

		{
			let mut serial = self.serial.lock().unwrap();
			// Use chunks to avoid timeout
			for chunk in buf_filtered.chunks(64) {
				serial.write_all(chunk).unwrap();
			}
		}
		self.screen = new_screen;
	}
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum Mode {
	Graph = 0x0e,
	Text = 0x0f,
}

impl Default for Mode {
	fn default() -> Self {
		Self::Text
	}
}

/// Input from minitel keyboard
pub struct MinitelInput {
	serial: Arc<Mutex<Box<dyn SerialPort>>>,
}

impl MinitelInput {
	pub fn try_read(&mut self, buf: &mut [u8]) -> std::io::Result<Option<usize>> {
		let mut serial = self.serial.lock().unwrap();
		if serial.bytes_to_read()? > 0 {
			serial.read(buf).map(Some)
		} else {
			Ok(None)
		}
	}
}

impl Read for MinitelInput {
	fn read(&mut self, buf: &mut [u8]) -> std::io::Result<usize> {
		self.serial.lock().unwrap().read(buf)
	}
}

pub fn encode_char_to_minitel(c: char) -> Vec<u8> {
	match c {
		'À' => vec![25, 65, b'A'],
		'È' => vec![25, 65, b'E'],
		'Ù' => vec![25, 65, b'U'],
		'à' => vec![25, 65, b'a'],
		'è' => vec![25, 65, b'e'],
		'ù' => vec![25, 65, b'u'],
		'É' => vec![25, 66, b'E'],
		'é' => vec![25, 66, b'e'],
		'Â' => vec![25, 67, b'A'],
		'Ê' => vec![25, 67, b'E'],
		'Î' => vec![25, 67, b'I'],
		'Ô' => vec![25, 67, b'O'],
		'Û' => vec![25, 67, b'U'],
		'â' => vec![25, 67, b'a'],
		'ê' => vec![25, 67, b'e'],
		'î' => vec![25, 67, b'i'],
		'ô' => vec![25, 67, b'o'],
		'û' => vec![25, 67, b'u'],
		'Ë' => vec![25, 72, b'E'],
		'Ï' => vec![25, 72, b'I'],
		'ë' => vec![25, 72, b'e'],
		'ï' => vec![25, 72, b'i'],
		c => vec![c.try_into().unwrap()],
	}
}

pub mod prelude {
	pub use crate::{
		img,
		screen::{Color, FontSize, Graph, Screen, ScreenCell, ScreenCellContent},
		Minitel,
	};
}
