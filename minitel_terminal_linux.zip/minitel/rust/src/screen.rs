use crate::Mode;

#[derive(Clone)]
pub struct Screen {
	pub size: (usize, usize),
	pub cells: Vec<ScreenCell>,
	pub cursor: (usize, usize),
	pub display_cursor: bool,
}

impl Screen {
	pub fn new(size: (usize, usize)) -> Self {
		Self {
			size,
			cells: vec![ScreenCell::default(); size.0 * size.1],
			cursor: (0, 0),
			display_cursor: false,
		}
	}

	pub fn iter_cells(&self) -> impl Iterator<Item = ((usize, usize), &ScreenCell)> {
		self.cells
			.iter()
			.enumerate()
			.map(|(i, c)| ((i % self.size.0, i / self.size.0), c))
	}

	pub fn iter_cells_mut(&mut self) -> impl Iterator<Item = ((usize, usize), &mut ScreenCell)> {
		self.cells
			.iter_mut()
			.enumerate()
			.map(|(i, c)| ((i % self.size.0, i / self.size.0), c))
	}

	/// Position to the right, wrapping
	pub fn get_next_pos(&self, pos: (usize, usize), advance_by: usize) -> (usize, usize) {
		(
			(pos.0 + advance_by) % self.size.0,
			(pos.1 + (pos.0 + advance_by) / self.size.0) % self.size.1,
		)
	}

	pub fn pos_to_index(&self, pos: (usize, usize)) -> usize {
		pos.0 + pos.1 * self.size.0
	}

	pub fn write_text_at(&mut self, pos: (usize, usize), text: &str) {
		for (i, c) in (0..self.size.0 * self.size.1)
			.skip(self.pos_to_index(pos))
			.zip(text.chars())
		{
			self.cells[i].content = ScreenCellContent::Char(c);
		}
	}

	pub fn write_content_rect(&mut self, cells: &[ScreenCell], pos: (usize, usize), width: usize) {
		let mut cell_iter = cells.iter();

		for y in (pos.1..).map(|y| y % self.size.1) {
			for x in (pos.0..pos.0 + width).map(|x| x % self.size.0) {
				if let Some(cell) = cell_iter.next() {
					self.cells[y * self.size.0 + x] = *cell;
				} else {
					return;
				}
			}
		}
	}

	/// Write text at cursor and mutate cursor (wrapping lines and screen)
	pub fn write_text(&mut self, text: &str) {
		for c in text.chars() {
			if c == '\n' {
				self.cursor = (0, (self.cursor.1 + 1) % self.size.1);
			} else {
				let index = self.pos_to_index(self.cursor);
				self.cells[index].content = ScreenCellContent::Char(c);
				self.cursor = self.get_next_pos(self.cursor, 1);
			}
		}
	}

	/// Write text at cursor and mutate cursor (wrapping lines and screen)
	/// Clean end of lines
	pub fn write_text_clean(&mut self, text: &str) {
		for c in text.chars() {
			if c == '\n' {
				let next_cursor = (0, (self.cursor.1 + 1) % self.size.1);
				for i in self.pos_to_index(self.cursor)..self.pos_to_index(next_cursor) {
					self.cells[i].content = ScreenCellContent::Char(' ');
				}
				self.cursor = next_cursor;
			} else {
				let index = self.pos_to_index(self.cursor);
				self.cells[index].content = ScreenCellContent::Char(c);
				self.cursor = self.get_next_pos(self.cursor, 1);
			}
		}
	}
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub struct Graph(pub u8);

impl Default for Graph {
	fn default() -> Self {
		Self(0b00100000)
	}
}

impl Graph {
	pub fn get_single_pixel(row: usize, col: usize) -> u8 {
		match (row, col) {
			(0, 0) => 1 << 0,
			(0, 1) => 1 << 1,
			(1, 0) => 1 << 2,
			(1, 1) => 1 << 3,
			(2, 0) => 1 << 4,
			(2, 1) => 1 << 6,
			_ => 0,
		}
	}
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum ScreenCellContent {
	Char(char),
	Graph(Graph),
}

impl ScreenCellContent {
	pub fn mode(self) -> Mode {
		match self {
			Self::Char(_) => Mode::Text,
			Self::Graph(_) => Mode::Graph,
		}
	}
}

impl Default for ScreenCellContent {
	fn default() -> Self {
		Self::Char(' ')
	}
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum FontSize {
	Normal = 0x4c,
	DoubleHeight = 0x4d,
	DoubleWidth = 0x4e,
	DoubleSize = 0x4f,
}

impl Default for FontSize {
	fn default() -> Self {
		Self::Normal
	}
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum Color {
	C0 = 0,
	C1 = 1,
	C2 = 2,
	C3 = 3,
	C4 = 4,
	C5 = 5,
	C6 = 6,
	C7 = 7,
}

impl Color {
	const MAP_TABLE: &'static [u8] = &[0, 4, 1, 5, 2, 6, 3, 7];

	pub const WHITE: Self = Color::C7;
	pub const BLACK: Self = Color::C0;

	pub(crate) fn foreground(self) -> [u8; 2] {
		[0x1b, 0x40 | Self::MAP_TABLE[self as usize]]
	}
}

impl Default for Color {
	fn default() -> Self {
		Self::WHITE
	}
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, Default)]
pub struct ScreenCell {
	pub content: ScreenCellContent,
	pub inverse: bool,
	pub blink: bool,
	pub foreground_color: Color,
	pub font_size: FontSize,
}

impl ScreenCell {
	pub fn is_empty(&self) -> bool {
		(self.content == ScreenCellContent::Char(' ')
			|| self.content == ScreenCellContent::Graph(Graph::default()))
			&& !self.inverse
			&& !self.blink
			&& self.font_size == FontSize::Normal
	}
}
