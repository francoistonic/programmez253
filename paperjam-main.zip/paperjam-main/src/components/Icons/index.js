export { default as IcWeb } from './IcWeb';
export { default as IcTwitter } from './IcTwitter';
export { default as IcCart } from './IcCart';
export { default as IcBag } from './IcBag';
export { default as IcAddToCart } from './IcAddToCart';
